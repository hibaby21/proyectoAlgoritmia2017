package proyecto.algoritmia;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JScrollPane;
import javax.swing.ScrollPaneConstants;
import javax.swing.JTextArea;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class DialogoListar extends JDialog implements ActionListener {

	private final JPanel contentPanel = new JPanel();
	private JScrollPane scrollPane;
	private JTextArea txtS;
	private JButton btnNewButton;
	private JButton btnNewButton_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			DialogoListar dialog = new DialogoListar();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public DialogoListar() {
		setBounds(100, 100, 533, 348);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		
		scrollPane = new JScrollPane();
		scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
		scrollPane.setBounds(10, 11, 507, 250);
		contentPanel.add(scrollPane);
		txtS = new JTextArea();
		txtS.setColumns(4);
		txtS.setForeground(Color.BLACK);
		txtS.setFont(new Font("monospaced", Font.PLAIN, 12));
		scrollPane.setViewportView(txtS);
		
		btnNewButton = new JButton("Cerrar");
		btnNewButton.addActionListener(this);
		btnNewButton.setBounds(158, 275, 89, 23);
		contentPanel.add(btnNewButton);
		
		btnNewButton_1 = new JButton("Listar");
		btnNewButton_1.setBounds(268, 275, 89, 23);
		contentPanel.add(btnNewButton_1);
		
		listar();
	}
	
	void listar(){
		String[] nombres = {" Precio I/V"," Precio Ida"," N� de maletas I/V"," N� de maletas Ida"," Puntos I/V"," Puntos Ida"};
		String[] clases = {" Clase Economica"," Clase Econ. Premium"," Clase de Negocios"," Primera Clase"};
		txtS.setText(" \n"+" LISTADO DE PASAJES" + "\n\n");
		imprimir(nombres, clases);//		imprimir(nombres);
	}
	
	void imprimir(String[] nombres, String[] clases){
		int indexPar = 0;
		int indexImpar = 1;
		for(int counter = 0; counter<4;counter++){
			txtS.append(clases[counter] + "\n");
			txtS.append(String.format("%-23s %-10s %-10s %-10s %-15s %-15s" , " Destinos", "Brasil", "EUA", "Mexico", "Puerto Rico", "Rusia")+ "\n");
			txtS.append(String.format("%-23s %-10s %-10s %-10s %-15s %-15s" , nombres[0], Tienda.preciosBr[indexPar], Tienda.preciosEUA[indexPar], Tienda.preciosMx[indexPar], Tienda.preciosPr[indexPar],Tienda.preciosRu[indexPar]) + "\n");
			txtS.append(String.format("%-23s %-10s %-10s %-10s %-15s %-15s" , nombres[1], Tienda.preciosBr[indexImpar], Tienda.preciosEUA[indexImpar], Tienda.preciosMx[indexImpar], Tienda.preciosPr[indexImpar],Tienda.preciosRu[indexImpar]) + "\n");
			txtS.append(String.format("%-23s %-10s %-10s %-10s %-15s %-15s" , nombres[2], Tienda.cantMaletasBr[indexPar], Tienda.cantMaletasEUA[indexPar], Tienda.cantMaletasMx[indexPar], Tienda.cantMaletasPr[indexPar],Tienda.cantMaletasRu[indexPar]) + "\n");
			txtS.append(String.format("%-23s %-10s %-10s %-10s %-15s %-15s" , nombres[3], Tienda.cantMaletasBr[indexImpar], Tienda.cantMaletasEUA[indexImpar], Tienda.cantMaletasMx[indexImpar], Tienda.cantMaletasPr[indexImpar],Tienda.cantMaletasRu[indexImpar])+ "\n");
			txtS.append(String.format("%-23s %-10s %-10s %-10s %-15s %-15s" , nombres[4], Tienda.cantPuntosBr[indexPar], Tienda.cantPuntosEUA[indexPar], Tienda.cantPuntosMx[indexPar], Tienda.cantPuntosPr[indexPar],Tienda.cantPuntosRu[indexPar])+ "\n");
			txtS.append(String.format("%-23s %-10s %-10s %-10s %-15s %-15s" , nombres[5], Tienda.cantPuntosBr[indexImpar], Tienda.cantPuntosEUA[indexImpar], Tienda.cantPuntosMx[indexImpar], Tienda.cantPuntosPr[indexImpar],Tienda.cantPuntosRu[indexImpar])+ "\n\n");

			indexPar=indexPar+2;
			indexImpar = indexImpar +2;
		}
	}
	
	
	
	
	public void actionPerformed(ActionEvent arg0) {
		if (arg0.getSource() == btnNewButton) {
			actionPerformedBtnNewButton(arg0);
		}
	}
	protected void actionPerformedBtnNewButton(ActionEvent arg0) {
	}
}
