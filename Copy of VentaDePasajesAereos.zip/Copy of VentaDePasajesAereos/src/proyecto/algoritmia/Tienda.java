package proyecto.algoritmia;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Tienda extends JFrame implements ActionListener {

	private JPanel contentPane;
	private JMenuBar menuBar;
	private JMenu mnNewMenu;
	private JMenuItem mntmXss;
	private JMenu mnNewMenu_1;
	private JMenu mnNewMenu_2;
	private JMenu mnNewMenu_3;
	private JMenu mnNewMenu_4;
	private JMenuItem mntmNewMenuItem;
	private JMenuItem mntmNewMenuItem_1;
	private JMenuItem mntmNewMenuItem_2;
	private JMenuItem mntmNewMenuItem_3;
	private JMenuItem mntmNewMenuItem_4;
	private JMenuItem mntmNewMenuItem_5;
	private JMenuItem mntmNewMenuItem_6;
	private JMenuItem mntmNewMenuItem_7;
	private JMenuItem mntmNewMenuItem_8;
	private JMenuItem mntmNewMenuItem_9;
	
	//Declaracion de precios, economico ida y vuelta, economico solo ida, economico premium ida y vuelta, etc
		static Double[] preciosBr = {600.00,350.00,680.00,400.00,799.00,460.00,999.00,600.00};
		static Double[] preciosEUA ={650.00,350.00,700.00,400.00,850.00,500.00,1050.00,700.00};
		static Double[] preciosMx = {620.00,370.00,700.00,420.00,820.00,480.00,1020.00,680.00};
		static Double[] preciosPr = {500.00,300.00,550.00,350.00,700.00,450.00,900.00,550.00};
		static Double[] preciosRu = {1000.00,750.00,1100.00,850.00,1350.00,1000.00,1700.00,1300.00};
	
	//Declaracion de cantidad de maletas
	static int[] cantMaletasBr = {2,2,2,2,2,2,2,2};
	static int[] cantMaletasEUA= {2,2,2,2,2,2,2,2};
	static int[] cantMaletasMx = {2,2,2,2,2,2,2,2};
	static int[] cantMaletasPr = {2,2,2,2,2,2,2,2};
	static int[] cantMaletasRu = {2,2,2,2,2,2,2,2};
	
	// Declaracion de cantidad de puntos ganados
	static int[] cantPuntosBr = {100,50,200,100,300,150,400,200};
	static int[] cantPuntosEUA ={150,75,250,125,350,175,450,225};
	static int[] cantPuntosMx = {125,70,225,125,325,165,425,215};
	static int[] cantPuntosPr = {80,40,160,80,250,125,350,175};
	static int[] cantPuntosRu = {200,150,300,250,400,350,500,450};
	
	//Declarando variables para la ventana de reportes
	public static int cantVentasEcon = 0;
	public static int cantPasajesEcon = 0;
	public static double impTotalEcon= 0.00;
	
	public static int cantVentasEconPremium = 0;
	public static int cantPasajesEconPremium = 0;
	public static double impTotalEconPremium= 0.00;
	
	public static int cantVentasNegocios = 0;
	public static int cantPasajesNegocios= 0;
	public static double impTotalNegocios= 0.00;
	
	public static int cantVentasPrimera = 0;
	public static int cantPasajesPrimera = 0;
	public static double impTotalPrimera= 0.00;
	
	public static double impTotalGeneral = impTotalEcon+impTotalEconPremium+impTotalNegocios+impTotalPrimera;
	// Datos m�nimos del primer pasaje 
	public static String pasaje0 = "Clase Economica"; 
	public static double precio0 = 450.0; 
	public static int cantMaletas0 = 2; 
	public static int puntos = 100; 
	 
	// Datos m�nimos del segundo modelo 
	public static String pasaje1 = "Clase Economica Premium"; 
	public static double precio1 = 550.0; 
	public static int cantMaletas1 = 2; 
	public static int nluces1 = 200;
	// Datos m�nimos del tercer modelo 
	public static String pasaje2 = "Clase de Negocios"; 
	public static double precio2 = 699.0; 
	public static int cantMaletas2 = 3; 
	public static int nluces2 = 300; 
	 
	// Datos m�nimos del cuarto modelo 
	public static String pasaje3 = "Primera Clase"; 
	public static double precio3 = 999.0; 
	public static int cantMaletas3 = 4; 
	public static int nluces3 = 400; 
	 
	 
	// Porcentajes de descuento de acuerdo a la cantidad de pasajes cmprados
	public static double porcentaje1 = 0.05; 
	public static double porcentaje2 = 0.10; 
	public static double porcentaje3 = 0.15; 
	public static double porcentaje4 = 0.20; 
	 
	// Cantidad �ptima de pasajes vendidos
	public static int cantidadOptima = 4000; 
	 
	// Modelo para el cual se otorga el obsequio 
	public static int modeloObsequiable = 0; 
	 
	// Cantidad m�nima de l�mparas adquiridas para obtener el obsequio 
	public static int cantidadMinimaObsequiable = 4;  
	// Obsequio 
	public static String obsequio = "S/.300 de credito para hospedarse en cualquier hotel"; 
	 
	// N�mero de cliente que recibe el premio sorpresa
	public static int numeroClienteSorpresa = 7; 
	 
	// Premio sorpresa
	public static String premioSorpresa = "Netflix gratis por 6 meses"; 

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Tienda frame = new Tienda();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Tienda() {
		setTitle("Teinda Principal");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		
		menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		mnNewMenu = new JMenu("Archivo");
		menuBar.add(mnNewMenu);
		
		mntmXss = new JMenuItem("Salir");
		mnNewMenu.add(mntmXss);
		
		mnNewMenu_1 = new JMenu("Mantenimiento");
		menuBar.add(mnNewMenu_1);
		
		mntmNewMenuItem = new JMenuItem("Consultar pasajes");
		mntmNewMenuItem.addActionListener(this);
		mnNewMenu_1.add(mntmNewMenuItem);
		
		mntmNewMenuItem_1 = new JMenuItem("Modificar pasajes");
		mntmNewMenuItem_1.addActionListener(this);
		mnNewMenu_1.add(mntmNewMenuItem_1);
		
		mntmNewMenuItem_2 = new JMenuItem("Listar pasajes");
		mntmNewMenuItem_2.addActionListener(this);
		mnNewMenu_1.add(mntmNewMenuItem_2);
		
		mnNewMenu_2 = new JMenu("Ventas");
		menuBar.add(mnNewMenu_2);
		
		mntmNewMenuItem_3 = new JMenuItem("Vender");
		mntmNewMenuItem_3.addActionListener(this);
		mnNewMenu_2.add(mntmNewMenuItem_3);
		
		mntmNewMenuItem_4 = new JMenuItem("Generar reportes");
		mntmNewMenuItem_4.addActionListener(this);
		mnNewMenu_2.add(mntmNewMenuItem_4);
		
		mnNewMenu_3 = new JMenu("Configuraci\u00F3n");
		menuBar.add(mnNewMenu_3);
		
		mntmNewMenuItem_5 = new JMenuItem("Configurar descuentos");
		mnNewMenu_3.add(mntmNewMenuItem_5);
		
		mntmNewMenuItem_6 = new JMenuItem("Configurar obsequio");
		mnNewMenu_3.add(mntmNewMenuItem_6);
		
		mntmNewMenuItem_7 = new JMenuItem("Configurar cantidad \u00F3ptima de pasajes vendidos");
		mnNewMenu_3.add(mntmNewMenuItem_7);
		
		mntmNewMenuItem_8 = new JMenuItem("Configurar premio sorpresa");
		mnNewMenu_3.add(mntmNewMenuItem_8);
		
		mnNewMenu_4 = new JMenu("Ayuda");
		menuBar.add(mnNewMenu_4);
		
		mntmNewMenuItem_9 = new JMenuItem("Acerca de Tienda");
		mnNewMenu_4.add(mntmNewMenuItem_9);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
	}
	public void actionPerformed(ActionEvent arg0) {
		if (arg0.getSource() == mntmNewMenuItem_2) {
			actionPerformedMntmNewMenuItem_2(arg0);
		}
		if (arg0.getSource() == mntmNewMenuItem_4) {
			actionPerformedMntmNewMenuItem_4(arg0);
		}
		if (arg0.getSource() == mntmNewMenuItem) {
			actionPerformedMntmNewMenuItem(arg0);
		}
		if (arg0.getSource() == mntmNewMenuItem_1) {
			actionPerformedMntmNewMenuItem_1(arg0);
		}
		if (arg0.getSource() == mntmNewMenuItem_3) {
			actionPerformedMntmNewMenuItem_3(arg0);
		}
	}
	protected void actionPerformedMntmNewMenuItem_3(ActionEvent arg0) {
		DialogoVender dialogoVender = new DialogoVender();
		dialogoVender.setLocationRelativeTo(this);
		dialogoVender.setVisible(true);
	}
	protected void actionPerformedMntmNewMenuItem_1(ActionEvent arg0) {
		DialogoModificar dialogoModificar = new DialogoModificar();
		dialogoModificar.setLocationRelativeTo(this);
		dialogoModificar.setVisible(true);
	}
	protected void actionPerformedMntmNewMenuItem(ActionEvent arg0) {
		DialogoConsultar dialogoConsultar= new DialogoConsultar();
		dialogoConsultar.setLocationRelativeTo(this);
		dialogoConsultar.setVisible(true);
	}
	protected void actionPerformedMntmNewMenuItem_4(ActionEvent arg0) {
		DialogoReportes dialogoReportes = new DialogoReportes();
		dialogoReportes.setLocationRelativeTo(this);
		dialogoReportes.setVisible(true);
	}
	protected void actionPerformedMntmNewMenuItem_2(ActionEvent arg0) {
		DialogoListar dialogoListar = new DialogoListar();
		dialogoListar.setLocationRelativeTo(this);
		dialogoListar.setVisible(true);
	}
}
