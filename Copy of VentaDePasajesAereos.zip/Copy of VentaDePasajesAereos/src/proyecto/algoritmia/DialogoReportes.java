package proyecto.algoritmia;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JScrollPane;
import javax.swing.ScrollPaneConstants;
import javax.swing.JTextArea;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class DialogoReportes extends JDialog implements ActionListener {

	private final JPanel contentPanel = new JPanel();
	private JLabel lblReporte;
	private JComboBox cboReporte;
	private JButton btnProcesar;
	private JScrollPane scrollPane;
	private JTextArea txtS;
	
	//Declaracion de variables
	int tipoDeReporte;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			DialogoReportes dialog = new DialogoReportes();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public DialogoReportes() {
		setTitle("Generar Reportes");
		setBounds(100, 100, 547, 300);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		
		lblReporte = new JLabel("Tipo de Reporte");
		lblReporte.setBounds(10, 22, 114, 14);
		contentPanel.add(lblReporte);
		
		cboReporte = new JComboBox();
		cboReporte.setModel(new DefaultComboBoxModel(new String[] {"Ventas por clase", "Pasajes con venta \u00F3ptima ", "Precios en relaci\u00F3n al promedio", "Promedios, m\u00E1ximos y m\u00EDnimos"}));
		cboReporte.setBounds(117, 19, 277, 20);
		contentPanel.add(cboReporte);
		
		btnProcesar = new JButton("Procesar");
		btnProcesar.addActionListener(this);
		btnProcesar.setBounds(432, 18, 89, 23);
		contentPanel.add(btnProcesar);
		
		scrollPane = new JScrollPane();
		scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
		scrollPane.setBounds(10, 54, 511, 196);
		contentPanel.add(scrollPane);
		
		txtS = new JTextArea();
		txtS.setFont(new Font("monospaced", Font.PLAIN, 12));
		scrollPane.setViewportView(txtS);
		
	}
	
	public void actionPerformed(ActionEvent arg0) {
		if (arg0.getSource() == btnProcesar) {
			actionPerformedBtnProcesar(arg0);
		}
	}
	protected void actionPerformedBtnProcesar(ActionEvent arg0) {
		tipoDeReporte = cboReporte.getSelectedIndex();
		generarReportes();
	}
	
	void generarReportes(){
		switch (tipoDeReporte) {
		case 0:
			generarReporteDeVentas();
			break;
		case 1:
			generarReporteVentasOptimas();
			break;
		case 2:
			generarRelacionDePrecios();
			break;
		case 3:
			generarMaxMinPromedios();
			break;

		default:
			break;
		}
	}
	
	void generarReporteDeVentas(){
		
		txtS.setText(String.format("%-37s %-10s " , "Clase", ":  ECONOMICA") + "\n");
		txtS.append(String.format("%-37s %-10s " , "Cantidad total de ventas", ":  "+Tienda.cantVentasEcon) + "\n");
		txtS.append(String.format("%-37s %-10s " , "Cantidad total de unidades vendidas", ":  "+Tienda.cantPasajesEcon) + "\n");
		txtS.append(String.format("%-37s %-10s " , "Importe total acumulado ", ":  "+Tienda.impTotalEcon) + "\n\n");
		txtS.append(String.format("%-37s %-10s " , "Clase", ":  ECONOMICA PREMIUM") + "\n");
		txtS.append(String.format("%-37s %-10s " , "Cantidad total de ventas", ":  "+Tienda.cantVentasEconPremium) + "\n");
		txtS.append(String.format("%-37s %-10s " , "Cantidad total de unidades vendidas", ":  "+Tienda.cantPasajesEconPremium) + "\n");
		txtS.append(String.format("%-37s %-10s " , "Importe total acumulado ", ":  "+Tienda.impTotalEconPremium) + "\n\n");
		txtS.append(String.format("%-37s %-10s " , "Clase", ":  NEGOCIOS") + "\n");
		txtS.append(String.format("%-37s %-10s " , "Cantidad total de ventas", ":  "+Tienda.cantVentasNegocios) + "\n");
		txtS.append(String.format("%-37s %-10s " , "Cantidad total de unidades vendidas", ":  "+Tienda.cantPasajesNegocios) + "\n");
		txtS.append(String.format("%-37s %-10s " , "Importe total acumulado ", ":  "+Tienda.impTotalNegocios) + "\n\n");
		txtS.append(String.format("%-37s %-10s " , "Clase", ":  PRIMERA") + "\n");
		txtS.append(String.format("%-37s %-10s " , "Cantidad total de ventas", ":  "+Tienda.cantVentasPrimera) + "\n");
		txtS.append(String.format("%-37s %-10s " , "Cantidad total de unidades vendidas", ":  "+Tienda.cantPasajesPrimera) + "\n");
		txtS.append(String.format("%-37s %-10s " , "Importe total acumulado ", ":  "+Tienda.impTotalPrimera) + "\n\n");
		txtS.append(String.format("%-37s %-10s " , "Importe total acumulado general ", ":  "+(Tienda.impTotalEcon+Tienda.impTotalEconPremium+Tienda.impTotalNegocios+Tienda.impTotalPrimera)) + "\n");
		

	}
	
	void generarReporteVentasOptimas(){
		int pasajesEcon = Tienda.cantPasajesEcon;
		int pasajesEconPremium = Tienda.cantPasajesEconPremium;
		int pasajesNegocios = Tienda.cantPasajesNegocios;
		int pasajesPrimera = Tienda.cantPasajesPrimera;
		int cantidadOptima = Tienda.cantidadOptima;
		if(pasajesEcon>cantidadOptima||pasajesEconPremium>cantidadOptima||pasajesNegocios>cantidadOptima||pasajesPrimera>cantidadOptima){
			txtS.setText("PASAJES CON VENTA OPTIMA" +"\n\n");
			if(pasajesEcon>cantidadOptima){
				txtS.append(String.format("%-37s %-10s " , "Clase", ":  Economica") + "\n");
				txtS.append(String.format("%-37s %-10s " , "Cantidad total de unidades vendidas", ":  "+Tienda.cantPasajesEcon) + "\n\n");
			}
			if (pasajesEconPremium>cantidadOptima) {
				txtS.append(String.format("%-37s %-10s " , "Clase", ":  Economica Premium") + "\n");
				txtS.append(String.format("%-37s %-10s " , "Cantidad total de unidades vendidas", ":  "+Tienda.cantPasajesEconPremium) + "\n\n");
			}
			if (pasajesNegocios>cantidadOptima) {
				txtS.append(String.format("%-37s %-10s " , "Clase", ":  Negocios") + "\n");
				txtS.append(String.format("%-37s %-10s " , "Cantidad total de unidades vendidas", ":  "+Tienda.cantPasajesNegocios) + "\n\n");
			}
			if (pasajesPrimera>cantidadOptima) {
				txtS.append(String.format("%-37s %-10s " , "Clase", ":  Primera") + "\n");
				txtS.append(String.format("%-37s %-10s " , "Cantidad total de unidades vendidas", ":  "+Tienda.cantPasajesPrimera) + "\n\n");
			}
		} else {
			txtS.setText("No existen pasajes con venta optima");
		}
		
	}
	
	void generarRelacionDePrecios(){
		String[] array ={"Economica", "Economica Premium", "Negocios", "Primera"};
		txtS.setText("PRECIOS EN  RELACI�N AL PROMEDIO" + "\n\n");
		for(int i = 0; i<4; i++){
			txtS.append(String.format("%-17s" , "Clase") + ":  "+ array[0]+"\n");
			
		}
	
	}
	
	void imprimir(){
	
	}
	
	void generarMaxMinPromedios(){
		
	}
}
