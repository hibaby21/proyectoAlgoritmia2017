package proyecto.algoritmia;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class DialogoCantidadOptima extends JDialog implements ActionListener {

	private final JPanel contentPanel = new JPanel();
	private JTextField txtCantidad;
	private JButton btnNewButton;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			DialogoCantidadOptima dialog = new DialogoCantidadOptima();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public DialogoCantidadOptima() {
		setBounds(100, 100, 489, 152);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		{
			JLabel lblNewLabel = new JLabel("Cantidad optima de pasajes vendidos");
			lblNewLabel.setBounds(10, 24, 234, 14);
			contentPanel.add(lblNewLabel);
		}
		{
			txtCantidad = new JTextField();
			txtCantidad.setToolTipText("");
			txtCantidad.setBounds(239, 21, 86, 20);
			contentPanel.add(txtCantidad);
			txtCantidad.setColumns(10);
			txtCantidad.setText(String.valueOf(Tienda.cantidadOptima));
		}
		{
			btnNewButton = new JButton("Aceptar");
			btnNewButton.addActionListener(this);
			btnNewButton.setBounds(377, 20, 86, 23);
			contentPanel.add(btnNewButton);
		}
		{
			JButton btnNewButton_1 = new JButton("Cancelar");
			btnNewButton_1.setBounds(377, 54, 86, 23);
			contentPanel.add(btnNewButton_1);
		}
	}

	public void actionPerformed(ActionEvent arg0) {
		if (arg0.getSource() == btnNewButton) {
			actionPerformedBtnNewButton(arg0);
		}
	}
	protected void actionPerformedBtnNewButton(ActionEvent arg0) {
		Tienda.cantidadOptima= Integer.parseInt(txtCantidad.getText());
	}
}
