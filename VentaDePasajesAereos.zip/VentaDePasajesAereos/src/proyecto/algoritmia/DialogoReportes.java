package proyecto.algoritmia;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JScrollPane;
import javax.swing.ScrollPaneConstants;
import javax.swing.JTextArea;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class DialogoReportes extends JDialog implements ActionListener {

	private final JPanel contentPanel = new JPanel();
	private JLabel lblReporte;
	private JComboBox cboReporte;
	private JButton btnProcesar;
	private JScrollPane scrollPane;
	private JTextArea txtS;
	
	//Declaracion de variables
	int tipoDeReporte;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			DialogoReportes dialog = new DialogoReportes();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public DialogoReportes() {
		setTitle("Generar Reportes");
		setBounds(100, 100, 547, 300);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		
		lblReporte = new JLabel("Tipo de Reporte");
		lblReporte.setBounds(10, 22, 114, 14);
		contentPanel.add(lblReporte);
		
		cboReporte = new JComboBox();
		cboReporte.setModel(new DefaultComboBoxModel(new String[] {"Ventas por clase", "Pasajes con venta \u00F3ptima ", "Precios en relaci\u00F3n al promedio", "Promedios, m\u00E1ximos y m\u00EDnimos"}));
		cboReporte.setBounds(117, 19, 277, 20);
		contentPanel.add(cboReporte);
		
		btnProcesar = new JButton("Procesar");
		btnProcesar.addActionListener(this);
		btnProcesar.setBounds(432, 18, 89, 23);
		contentPanel.add(btnProcesar);
		
		scrollPane = new JScrollPane();
		scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
		scrollPane.setBounds(10, 54, 511, 196);
		contentPanel.add(scrollPane);
		
		txtS = new JTextArea();
		txtS.setFont(new Font("monospaced", Font.PLAIN, 12));
		scrollPane.setViewportView(txtS);
		
	}
	
	public void actionPerformed(ActionEvent arg0) {
		if (arg0.getSource() == btnProcesar) {
			actionPerformedBtnProcesar(arg0);
		}
	}
	protected void actionPerformedBtnProcesar(ActionEvent arg0) {
		tipoDeReporte = cboReporte.getSelectedIndex();
		generarReportes();
	}
	
	void generarReportes(){
		switch (tipoDeReporte) {
		case 0:
			generarReporteDeVentas();
			break;
		case 1:
			generarReporteVentasOptimas();
			break;
		case 2:
			generarRelacionDePrecios();
			break;
		case 3:
			generarMaxMinPromedios();
			break;

		default:
			break;
		}
	}
	
	void generarReporteDeVentas(){
		
		txtS.setText(String.format("%-37s %-10s " , "Clase", ":  ECONOMICA") + "\n");
		txtS.append(String.format("%-37s %-10s " , "Cantidad total de ventas", ":  "+Tienda.cantVentasEcon) + "\n");
		txtS.append(String.format("%-37s %-10s " , "Cantidad total de unidades vendidas", ":  "+Tienda.cantPasajesEcon) + "\n");
		txtS.append(String.format("%-37s %-10s " , "Importe total acumulado ", ":  "+Tienda.impTotalEcon) + "\n\n");
		txtS.append(String.format("%-37s %-10s " , "Clase", ":  ECONOMICA PREMIUM") + "\n");
		txtS.append(String.format("%-37s %-10s " , "Cantidad total de ventas", ":  "+Tienda.cantVentasEconPremium) + "\n");
		txtS.append(String.format("%-37s %-10s " , "Cantidad total de unidades vendidas", ":  "+Tienda.cantPasajesEconPremium) + "\n");
		txtS.append(String.format("%-37s %-10s " , "Importe total acumulado ", ":  "+Tienda.impTotalEconPremium) + "\n\n");
		txtS.append(String.format("%-37s %-10s " , "Clase", ":  NEGOCIOS") + "\n");
		txtS.append(String.format("%-37s %-10s " , "Cantidad total de ventas", ":  "+Tienda.cantVentasNegocios) + "\n");
		txtS.append(String.format("%-37s %-10s " , "Cantidad total de unidades vendidas", ":  "+Tienda.cantPasajesNegocios) + "\n");
		txtS.append(String.format("%-37s %-10s " , "Importe total acumulado ", ":  "+Tienda.impTotalNegocios) + "\n\n");
		txtS.append(String.format("%-37s %-10s " , "Clase", ":  PRIMERA") + "\n");
		txtS.append(String.format("%-37s %-10s " , "Cantidad total de ventas", ":  "+Tienda.cantVentasPrimera) + "\n");
		txtS.append(String.format("%-37s %-10s " , "Cantidad total de unidades vendidas", ":  "+Tienda.cantPasajesPrimera) + "\n");
		txtS.append(String.format("%-37s %-10s " , "Importe total acumulado ", ":  "+Tienda.impTotalPrimera) + "\n\n");
		txtS.append(String.format("%-37s %-10s " , "Importe total acumulado general ", ":  "+(Tienda.impTotalEcon+Tienda.impTotalEconPremium+Tienda.impTotalNegocios+Tienda.impTotalPrimera)) + "\n");
		

	}
	
	void generarReporteVentasOptimas(){
		int pasajesEcon = Tienda.cantPasajesEcon;
		int pasajesEconPremium = Tienda.cantPasajesEconPremium;
		int pasajesNegocios = Tienda.cantPasajesNegocios;
		int pasajesPrimera = Tienda.cantPasajesPrimera;
		int cantidadOptima = Tienda.cantidadOptima;
		if(pasajesEcon>cantidadOptima||pasajesEconPremium>cantidadOptima||pasajesNegocios>cantidadOptima||pasajesPrimera>cantidadOptima){
			txtS.setText("PASAJES CON VENTA OPTIMA" +"\n\n");
			if(pasajesEcon>cantidadOptima){
				txtS.append(String.format("%-37s %-10s " , "Clase", ":  Economica") + "\n");
				txtS.append(String.format("%-37s %-10s " , "Cantidad total de unidades vendidas", ":  "+Tienda.cantPasajesEcon) + "\n\n");
			}
			if (pasajesEconPremium>cantidadOptima) {
				txtS.append(String.format("%-37s %-10s " , "Clase", ":  Economica Premium") + "\n");
				txtS.append(String.format("%-37s %-10s " , "Cantidad total de unidades vendidas", ":  "+Tienda.cantPasajesEconPremium) + "\n\n");
			}
			if (pasajesNegocios>cantidadOptima) {
				txtS.append(String.format("%-37s %-10s " , "Clase", ":  Negocios") + "\n");
				txtS.append(String.format("%-37s %-10s " , "Cantidad total de unidades vendidas", ":  "+Tienda.cantPasajesNegocios) + "\n\n");
			}
			if (pasajesPrimera>cantidadOptima) {
				txtS.append(String.format("%-37s %-10s " , "Clase", ":  Primera") + "\n");
				txtS.append(String.format("%-37s %-10s " , "Cantidad total de unidades vendidas", ":  "+Tienda.cantPasajesPrimera) + "\n\n");
			}
		} else {
			txtS.setText("No existen pasajes con venta optima");
		}
		
	}
	
	void generarRelacionDePrecios(){
		
		String[] clases ={"Economica", "Economica Premium", "Negocios", "Primera"};
		String[] destinos = {"Brasil", "EUA", "Mexico", "Puerto Rico", "Rusia"};
		txtS.setText(" PRECIOS EN  RELACI�N AL PROMEDIO" + "\n\n");
		String menorPromedio="(menor al promedio)";
		String mayorPromedio="(mayor al promedio)";
		for(int i = 0; i<clases.length; i++){
			double promedio = (Tienda.preciosBr[i]+Tienda.preciosEUA[i]+Tienda.preciosMx[i]+Tienda.preciosPr[i]+Tienda.preciosRu[i])/5;
			String[] array = {};
			
			txtS.append(String.format("%-23s" , " Clase") + ":  "+ clases[i]+"\n");
			if (Tienda.preciosBr[i]>promedio) {
				txtS.append(String.format("%-23s" ," Precio a Brasil ")+ ":  "+ Tienda.preciosBr[i]+" "+mayorPromedio+"\n");
			} else{
				txtS.append(String.format("%-23s" ," Precio a Brasil ")+ ":  "+ Tienda.preciosBr[i]+" "+menorPromedio+"\n");
			}
			
			if (Tienda.preciosEUA[i]>promedio) {
				txtS.append(String.format("%-23s" ," Precio a EUA")+ ":  "+ Tienda.preciosEUA[i]+" "+mayorPromedio+"\n");
			} else{
				txtS.append(String.format("%-23s" ," Precio a EUA")+ ":  "+ Tienda.preciosEUA[i]+" "+menorPromedio+"\n");
			}
			
			if (Tienda.preciosMx[i]>promedio) {
				txtS.append(String.format("%-23s" ," Precio a Mexico" )+ ":  "+ Tienda.preciosMx[i]+" "+mayorPromedio+"\n");
			} else{
				txtS.append(String.format("%-23s" ," Precio a Mexico" )+ ":  "+ Tienda.preciosMx[i]+" "+menorPromedio+"\n");
			}
			
			if (Tienda.preciosPr[i]>promedio) {
				txtS.append(String.format("%-23s" ," Precio a Puerto Rico")+ ":  "+ Tienda.preciosPr[i]+" "+mayorPromedio+"\n");
			} else{
				txtS.append(String.format("%-23s" ," Precio a Puerto Rico")+ ":  "+ Tienda.preciosPr[i]+" "+menorPromedio+"\n");
			}
			
			if (Tienda.preciosRu[i]>promedio) {
				txtS.append(String.format("%-23s" ," Precio a Rusia" )+ ":  "+ Tienda.preciosRu[i]+" "+mayorPromedio+"\n\n");
			} else{
				txtS.append(String.format("%-23s" ," Precio a Rusia") + ":  "+ Tienda.preciosRu[i]+" "+menorPromedio+"\n\n");
			}

			txtS.append(String.format("%-23s" ," Precio promedio" + ":  "+ promedio+"\n\n"));
					
		}
	
	}
	
	
	void generarMaxMinPromedios(){
		double[] preciosEcon = {Tienda.preciosBr[0],Tienda.preciosEUA[0],Tienda.preciosMx[0], Tienda.preciosPr[0], Tienda.preciosRu[0]};
		double[] preciosEconPremium = {Tienda.preciosBr[1],Tienda.preciosEUA[1],Tienda.preciosMx[1], Tienda.preciosPr[1], Tienda.preciosRu[1]};
		double[] preciosNegocios = {Tienda.preciosBr[2],Tienda.preciosEUA[2],Tienda.preciosMx[2], Tienda.preciosPr[2], Tienda.preciosRu[2]};
		double[] preciosPrimera = {Tienda.preciosBr[3],Tienda.preciosEUA[3],Tienda.preciosMx[3], Tienda.preciosPr[3], Tienda.preciosRu[3]};
		double promedioEconomico =(preciosEcon[0]+preciosEcon[1]+preciosEcon[2]+preciosEcon[3]+preciosEcon[4])/5;
		double promedioEconPremium =(preciosEconPremium[0]+preciosEconPremium[1]+preciosEconPremium[2]+preciosEconPremium[3]+preciosEconPremium[4])/5;
		double promedioNegocios =(preciosNegocios[0]+preciosNegocios[1]+preciosNegocios[2]+preciosNegocios[3]+preciosNegocios[4])/5;
		double promedioPrimera =(preciosPrimera[0]+preciosPrimera[1]+preciosPrimera[2]+preciosPrimera[3]+preciosPrimera[4])/5;
		double econMax = 0, econMin = preciosEcon[0];
		double econPremiumMax = 0, econPremiumMin = preciosEconPremium[0];
		double negociosMax = 0, negociosMin = preciosNegocios[0];
		double primeraMax = 0, primeraMin = preciosPrimera[0];
		
		for (int j = 0; j < 4; j++) {
			for (int counter = 0; counter < 5; counter++){
			     if (preciosEcon[counter] > econMax){
			    	 econMax = preciosEcon[counter];
			     }
			     if (preciosEcon[counter] < econMin){
			    	 econMin = preciosEcon[counter];
			     }
			     
			     if (preciosEconPremium[counter] > econPremiumMax){
			    	 econPremiumMax = preciosEconPremium[counter];
			     }
			     if (preciosEconPremium[counter] < econPremiumMin){
			    	 econPremiumMin = preciosEconPremium[counter];
			     }
			     
			     if (preciosNegocios[counter] > negociosMax){
			    	 negociosMax = preciosNegocios[counter];
			     }
			     if (preciosNegocios[counter] < negociosMin){
			    	 negociosMin = preciosNegocios[counter];
			     }
			     
			     if (preciosPrimera[counter] > primeraMax){
			    	 primeraMax = preciosPrimera[counter];
			     }
			     if (preciosPrimera[counter] < primeraMin){
			    	 primeraMin = preciosPrimera[counter];
			     }
			}
		}
	
		txtS.setText(" PROMEDIOS, M�XIMOS Y M�NIMOS"+"\n\n");
		txtS.append(String.format("%-23s" ," Precio economico promedio")+ ":  "+ promedioEconomico+"\n");
		txtS.append(String.format("%-23s" ," Precio economico minimo")+ ":  "+ econMin+"\n");
		txtS.append(String.format("%-23s" ," Precio economico maximo")+ ":  "+ econMax+"\n\n");
		txtS.append(String.format("%-23s" ," Precio econ. premium promedio")+ ":  "+ promedioEconPremium+"\n");
		txtS.append(String.format("%-23s" ," Precio econ. premium minimo")+ ":  "+ econPremiumMin+"\n");
		txtS.append(String.format("%-23s" ," Precio econ. premium maximo")+ ":  "+ econPremiumMax+"\n\n");
		txtS.append(String.format("%-23s" ," Precio de negocios promedio")+ ":  "+ promedioNegocios+"\n");
		txtS.append(String.format("%-23s" ," Precio de negocios minimo")+ ":  "+ negociosMin+"\n");
		txtS.append(String.format("%-23s" ," Precio de negocios maximo")+ ":  "+ negociosMax+"\n\n");
		txtS.append(String.format("%-23s" ," Precio primera promedio")+ ":  "+ promedioPrimera+"\n");
		txtS.append(String.format("%-23s" ," Precio primera minimo")+ ":  "+ primeraMin+"\n");
		txtS.append(String.format("%-23s" ," Precio primera maximo")+ ":  "+ primeraMax+"\n\n");
	}
}
