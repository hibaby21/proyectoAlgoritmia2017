package proyecto.algoritmia;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import javax.swing.DefaultComboBoxModel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class DialogoModificar extends JDialog implements ActionListener {

	private final JPanel contentPanel = new JPanel();
	private JButton btnBorrar;
    private JComboBox cboClase;
	private JComboBox cboDestino;
	private JLabel lblClase;
	private JTextField txtPrecio;
	private JTextField txtCantMaletas;
	private JTextField txtCantPuntos;
	private JLabel lblNewLabel;
	private JLabel lblNewLabel_1;
	private JLabel lblNewLabel_2;
	private JButton btnGenerarAutomaticamente;
	private JButton btnGuardar;
	String guardarOMostrar="Mostrar";
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			DialogoModificar dialog = new DialogoModificar();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public DialogoModificar() {
		setTitle("Modificar");
		setBounds(100, 100, 511, 300);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		{
			JLabel lblDestino = new JLabel("Destino");
			lblDestino.setBounds(10, 22, 91, 14);
			contentPanel.add(lblDestino);
		}
		
		btnBorrar = new JButton("Borrar");
		btnBorrar.addActionListener(this);
		btnBorrar.setBounds(396, 18, 89, 23);
		contentPanel.add(btnBorrar);
		
		cboClase = new JComboBox();
		cboClase.setModel(new DefaultComboBoxModel(new String[] {"Economica", "Economica Premium", "Negocios", "Primera"}));
		cboClase.setBounds(132, 53, 115, 20);
		cboClase.addItemListener(new ItemHandler());
		contentPanel.add(cboClase);
		
		cboDestino = new JComboBox();
		cboDestino.setModel(new DefaultComboBoxModel(new String[] {"Brazil", "Estados Unidos", "Mexico", "Puerto Rico", "Rusia"}));
		cboDestino.setBounds(132, 19, 115, 20);
		cboDestino.addItemListener(new ItemHandler());
		contentPanel.add(cboDestino);
		
		lblClase = new JLabel("Clase");
		lblClase.setBounds(10, 56, 91, 14);
		contentPanel.add(lblClase);
		
		txtPrecio = new JTextField();
		txtPrecio.setBounds(132, 90, 115, 20);
		contentPanel.add(txtPrecio);
		txtPrecio.setColumns(10);
		txtPrecio.setText(String.valueOf(Tienda.preciosBr[0]));
		
		txtCantMaletas = new JTextField();
		txtCantMaletas.setBounds(132, 122, 115, 20);
		contentPanel.add(txtCantMaletas);
		txtCantMaletas.setColumns(10);
		txtCantMaletas.setText(String.valueOf(Tienda.cantMaletasBr[0]));
		
		txtCantPuntos = new JTextField();
		txtCantPuntos.setBounds(132, 155, 115, 20);
		contentPanel.add(txtCantPuntos);
		txtCantPuntos.setColumns(10);
		txtCantPuntos.setText(String.valueOf(Tienda.cantPuntosBr[0]));
		
		lblNewLabel = new JLabel("Precio");
		lblNewLabel.setBounds(10, 91, 46, 14);
		contentPanel.add(lblNewLabel);
		
		lblNewLabel_1 = new JLabel("Cantidad de maletas");
		lblNewLabel_1.setBounds(10, 125, 124, 14);
		contentPanel.add(lblNewLabel_1);
		
		lblNewLabel_2 = new JLabel("Puntos Ganados");
		lblNewLabel_2.setBounds(10, 158, 91, 14);
		contentPanel.add(lblNewLabel_2);
		
		btnGenerarAutomaticamente = new JButton("Generar Precios");
		btnGenerarAutomaticamente.setBounds(343, 87, 142, 23);
		contentPanel.add(btnGenerarAutomaticamente);
		
		btnGuardar = new JButton("Guardar");
		btnGuardar.addActionListener(this);
		btnGuardar.setBounds(396, 52, 89, 23);
		contentPanel.add(btnGuardar);
	}
	
	@Override
	public void actionPerformed(ActionEvent arg0) {
		if (arg0.getSource() == btnGuardar) {
			actionPerformedBtnGuardar(arg0);
		}
		if (arg0.getSource() == btnBorrar) {
			actionPerformedBtnBorrar(arg0);
		}
		// TODO Auto-generated method stub

		
	}

	protected void actionPerformedBtnBorrar(ActionEvent arg0) {
		
	}
	
	protected void actionPerformedBtnGuardar(ActionEvent arg0) {
		guardarOMostrar="Guardar";
		ItemHandler handler = new ItemHandler();
		handler.procesarPrecio(cboClase.getSelectedIndex(), cboDestino.getSelectedIndex());
	}
	
	private class ItemHandler implements ItemListener{

		int pais, tipo, clase;
		@Override
		public void itemStateChanged(ItemEvent e) {
			// TODO Auto-generated method stub
			if (e.getSource()==cboClase) {
			procesarPrecio(cboClase.getSelectedIndex(),  cboDestino.getSelectedIndex());
			guardarOMostrar="Mostrar";
			}
		
			if (e.getSource()==cboDestino) {
				procesarPrecio(cboClase.getSelectedIndex(),  cboDestino.getSelectedIndex());
				guardarOMostrar="Mostrar";
			}
			
			
		}
		void procesarPrecio(int a, int c){
			pais = c;
			clase = a;
			chequearClase();
			
		}
		
		void chequearClase(){
			if(clase==0){
				chequearDestino(0);
			} else if (clase==1){
				chequearDestino(1);
			} else if (clase==2){
				chequearDestino(2);
			} else {
				chequearDestino(3);
			}
		}
		
		void chequearDestino(int index){
			if (guardarOMostrar.equals("Mostrar")) {
				mostrar(index);
			} else{
				guardar(index);
			}
		}
		
		void mostrar(int index){
			if(pais==0){
				txtPrecio.setText(String.valueOf(Tienda.preciosBr[index]));
				txtCantMaletas.setText(String.valueOf(Tienda.cantMaletasBr[index]));
				txtCantPuntos.setText(String.valueOf(Tienda.cantPuntosBr[index]));
			} else if(pais==1){
				txtPrecio.setText(String.valueOf(Tienda.preciosEUA[index]));
				txtCantMaletas.setText(String.valueOf(Tienda.cantMaletasEUA[index]));
				txtCantPuntos.setText(String.valueOf(Tienda.cantPuntosEUA[index]));
			}else if(pais==2){
				txtPrecio.setText(String.valueOf(Tienda.preciosMx[index]));
				txtCantMaletas.setText(String.valueOf(Tienda.cantMaletasMx[index]));
				txtCantPuntos.setText(String.valueOf(Tienda.cantPuntosMx[index]));
			} else if (pais==3) {
				txtPrecio.setText(String.valueOf(Tienda.preciosPr[index]));
				txtCantMaletas.setText(String.valueOf(Tienda.cantMaletasPr[index]));
				txtCantPuntos.setText(String.valueOf(Tienda.cantPuntosPr[index]));
			} else{
				txtPrecio.setText(String.valueOf(Tienda.preciosRu[index]));
				txtCantMaletas.setText(String.valueOf(Tienda.cantMaletasRu[index]));
				txtCantPuntos.setText(String.valueOf(Tienda.cantPuntosRu[index]));
			}
		}

		void guardar(int index){
			if(pais==0){
				Tienda.preciosBr[index]=Double.parseDouble(txtPrecio.getText());
				Tienda.cantMaletasBr[index]=Integer.parseInt(txtCantMaletas.getText());
				Tienda.cantPuntosBr[index]= Integer.parseInt(txtCantPuntos.getText());
			} else if(pais==1){
				Tienda.preciosEUA[index]=Double.parseDouble(txtPrecio.getText());
				Tienda.cantMaletasEUA[index]=Integer.parseInt(txtCantMaletas.getText());
				Tienda.cantPuntosEUA[index]= Integer.parseInt(txtCantPuntos.getText());
			}else if(pais==2){
				Tienda.preciosMx[index]=Double.parseDouble(txtPrecio.getText());
				Tienda.cantMaletasMx[index]=Integer.parseInt(txtCantMaletas.getText());
				Tienda.cantPuntosMx[index]= Integer.parseInt(txtCantPuntos.getText());
			} else if (pais==3) {
				Tienda.preciosPr[index]=Double.parseDouble(txtPrecio.getText());
				Tienda.cantMaletasPr[index]=Integer.parseInt(txtCantMaletas.getText());
				Tienda.cantPuntosPr[index]= Integer.parseInt(txtCantPuntos.getText());
			} else{
				Tienda.preciosRu[index]=Double.parseDouble(txtPrecio.getText());
				Tienda.cantMaletasRu[index]=Integer.parseInt(txtCantMaletas.getText());
				Tienda.cantPuntosRu[index]= Integer.parseInt(txtCantPuntos.getText());
			}
		}

	}
}
