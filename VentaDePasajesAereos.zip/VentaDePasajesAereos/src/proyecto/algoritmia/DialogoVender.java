package proyecto.algoritmia;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.text.BadLocationException;
import javax.swing.JLabel;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.text.DecimalFormat;
import java.awt.event.ActionEvent;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.ScrollPaneConstants;

public class DialogoVender extends JDialog implements ActionListener{

	private final JPanel contentPanel = new JPanel();
	private JButton btnVender;
	private JButton btnCerrar;
	private JLabel lblNewLabel;
	private JLabel lblNewLabel_3;
	private JLabel lblNewLabel_4;
	private JComboBox cboClase;
	private JTextField txtCantPas;
	private JTextField txtPrecio;
	private JScrollPane scrollPane;
	private JLabel lblNewLabel_1;
	private JComboBox cboDestino;
	
	//Declarar Variables
	double impComp, impDscto, impPag, precioPasaje;
	int cantPas, clase, tipoVuelo, destino, cantClientes;
	String claseVuelo, obsequio, premioSorpresa;
	private JTextArea txtS;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			DialogoVender dialog = new DialogoVender();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public DialogoVender() {
		setTitle("Vender");
		setBounds(100, 100, 450, 425);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		
		btnVender = new JButton("Vender");
		btnVender.addActionListener(this);
		btnVender.setBounds(335, 11, 89, 23);
		contentPanel.add(btnVender);
		
		btnCerrar = new JButton("Cerrar");
		btnCerrar.addActionListener(this);
		btnCerrar.setBounds(335, 45, 89, 23);
		contentPanel.add(btnCerrar);
		
		lblNewLabel = new JLabel("Clase");
		lblNewLabel.setBounds(10, 84, 104, 14);
		contentPanel.add(lblNewLabel);
		
		lblNewLabel_3 = new JLabel("Cantidad");
		lblNewLabel_3.setBounds(10, 49, 104, 14);
		contentPanel.add(lblNewLabel_3);
		
		lblNewLabel_4 = new JLabel("Precio");
		lblNewLabel_4.setBounds(10, 118, 104, 14);
		contentPanel.add(lblNewLabel_4);
		
		cboClase = new JComboBox();
		cboClase.setModel(new DefaultComboBoxModel(new String[] {"Economica", "Economica Premium", "Negocios", "Primera"}));
		cboClase.setBounds(124, 81, 133, 20);
		cboClase.addItemListener(new ItemHandler());
		contentPanel.add(cboClase);
		
		txtCantPas = new JTextField();
		txtCantPas.addActionListener(this);
		txtCantPas.setBounds(124, 46, 133, 20);
		contentPanel.add(txtCantPas);
		txtCantPas.setColumns(10);
		txtCantPas.setText("1");

		
		txtPrecio = new JTextField();
		txtPrecio.setEditable(false);
		txtPrecio.setBounds(124, 115, 133, 20);
		contentPanel.add(txtPrecio);
		txtPrecio.setText(String.valueOf(Tienda.preciosBr[0]));
		txtPrecio.setColumns(10);
		
		
		scrollPane = new JScrollPane();
		scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
		scrollPane.setBounds(10, 152, 414, 223);
		contentPanel.add(scrollPane);
		
		txtS = new JTextArea();
		txtS.setFont(new Font("monospaced", Font.PLAIN, 12));
		scrollPane.setViewportView(txtS);
		
		lblNewLabel_1 = new JLabel("Destino");
		lblNewLabel_1.setBounds(10, 15, 46, 14);
		contentPanel.add(lblNewLabel_1);
		
		cboDestino = new JComboBox();
		cboDestino.setModel(new DefaultComboBoxModel(new String[] {"Brasil", "Estados Unidos", "Mexico", "Puerto Rico", "Rusia"}));
		cboDestino.setBounds(124, 12, 133, 20);
		cboDestino.addItemListener(new ItemHandler());
		contentPanel.add(cboDestino);
	}
	public void actionPerformed(ActionEvent arg0) {
		if (arg0.getSource() == txtCantPas) {
//			actionPerformedTxtCantPas(arg0);
		}
		if (arg0.getSource() == btnCerrar) {
			actionPerformedBtnCerrar(arg0);
		}
		if (arg0.getSource() == btnVender) {
			actionPerformedBtnVender(arg0);
		}
	}
	protected void actionPerformedBtnVender(ActionEvent arg0) {
		cantClientes++;
		
		// Declaracion de variables
		clase = cboClase.getSelectedIndex();
		precioPasaje = Double.parseDouble(txtPrecio.getText());
		destino = cboDestino.getSelectedIndex();
		cantPas = Integer.parseInt(txtCantPas.getText());
		
		
		//Ejecutando los metodos
		ItemHandler handler = new ItemHandler();
		handler.procesarPrecio(clase, destino);
		calcClase();
		calcImpComp();
		calcImpDscto();
		calcImpPag();
		calcObsequio();
		calcPremioSorpresa();
		mostrarResultados();
		efectuarIncrementos();

		
	}
	
	protected void actionPerformedBtnCerrar(ActionEvent arg0) {
	}
	
	//En este metodo aumentamos la cantidad de comprar efectuadas de cada clase y tambien cuantos pasajes se an comprado
	protected void efectuarIncrementos(){
		switch (clase) {
		case 0:
			Tienda.cantVentasEcon = Tienda.cantVentasEcon + 1;
			Tienda.cantPasajesEcon = Tienda.cantPasajesEcon + cantPas;
			Tienda.impTotalEcon = Tienda.impTotalEcon + impPag;
			break;
		case 1:
			Tienda.cantVentasEconPremium = Tienda.cantVentasEconPremium + 1;
			Tienda.cantPasajesEconPremium = Tienda.cantPasajesEconPremium + cantPas;
			Tienda.impTotalEconPremium = Tienda.impTotalEconPremium + impPag;
			break;
		case 2:
			Tienda.cantVentasNegocios = Tienda.cantVentasNegocios + 1;
			Tienda.cantPasajesNegocios = Tienda.cantPasajesNegocios + cantPas;
			Tienda.impTotalNegocios = Tienda.impTotalNegocios + impPag;
			break;
		case 3:
			Tienda.cantVentasPrimera = Tienda.cantVentasPrimera + 1;
			Tienda.cantPasajesPrimera = Tienda.cantPasajesPrimera + cantPas;
			Tienda.impTotalPrimera = Tienda.impTotalPrimera + impPag;
			break;

		default:
			break;
		}
	}
	
	//aqui usamos el cbo para determinar que elemento se a escogido, de acuerdo a eso asignamos a una variable de tipo string la clade para asi usarla al momento de imprimirla
	protected void calcClase(){
		switch (clase) {
		case 0:
			claseVuelo = "Economica";
			break;
		case 1:
			claseVuelo = "Economica Premium";
			break;
		case 2:
			claseVuelo = "Negocios";
			break;
		case 3:
			claseVuelo = "Primera";
			break;
		default:
			break;
		}
	}
	
	// aqui calculamos el obsequio
	protected void calcObsequio(){
		if (clase==Tienda.modeloObsequiable&&cantPas>=Tienda.cantidadMinimaObsequiable) {
			obsequio = Tienda.obsequio;
		} else{
			obsequio = "Ninguno";
		}
	}
	
	protected void calcPremioSorpresa(){
		if (cantClientes==Tienda.numeroClienteSorpresa) {
			premioSorpresa = Tienda.premioSorpresa;
		} else{
			premioSorpresa = "Ninguno";
		}
	}
	
	protected void calcImpComp(){
		impComp = precioPasaje * cantPas;
	}
	
	protected void calcImpDscto(){
		if (cantPas<5) {
			impDscto = impComp * Tienda.porcentaje1;
		} else if (cantPas < 10) {
			impDscto = impComp * Tienda.porcentaje2;
		} else if (cantPas < 15) {
			impDscto = impComp * Tienda.porcentaje3;
		} else{
			impDscto = impComp * Tienda.porcentaje4;
		}
	}
	
	protected void calcImpPag(){
		impPag = impComp - impDscto;
	}
	
	protected void mostrarResultados(){
		txtS.setText(String.format("%-20s", "Clase") + " : " + claseVuelo + "\n" );
		imprimir(String.format("%-20s", "Precio de cada pasaje") + " : " + precioPasaje);
		imprimir(String.format("%-20s", "Pasajes comprados") + " : " + cantPas);
		imprimir(String.format("%-20s", "Importe de compra") + " : " + impComp);
		imprimir(String.format("%-20s", "Importe de descuento") + " : " + impDscto);
		imprimir(String.format("%-20s", "Importe de pago") + " : " + impPag);
		imprimir(String.format("%-20s", "Obsequio") + " : " + obsequio);
		imprimir(String.format("%-20s", "Premio Sorpresa") + " : " + premioSorpresa);

	}
	
	protected void imprimir(String cad){
		txtS.append(cad + "\n");
	}
	
	private class ItemHandler implements ItemListener{

		int pais, tipo, clase;
		
		@Override
		public void itemStateChanged(ItemEvent e) {
			// TODO Auto-generated method stub
			if (e.getSource()==cboClase) {
				//aqui pasamos los index de cada combobox
			procesarPrecio(cboClase.getSelectedIndex(), cboDestino.getSelectedIndex());
			}
				//aqui igual
			if (e.getSource()==cboDestino) {
				procesarPrecio(cboClase.getSelectedIndex(),  cboDestino.getSelectedIndex());

			}
			
			
		}
		
		//aqui recibimos los index de cada comobox, la a se le asignara a clase, la c a pais, por ejemplo si el cbo clase esta en el idex 0, clase sera igual a 0
		void procesarPrecio(int a, int c){
			pais = c;
			clase = a;
			chequearClase();
			
		}
		
		//aqui chequeamos la clase, si es 0 entonces es economico, si es 2 entonces es negocios, y llamamos un metodo para saber el pais
		void chequearClase(){
			if(clase==0){
				chequearDestino(0);
			} else if (clase==1){
				chequearDestino(1);
			} else if (clase==2){
				chequearDestino(2);
			} else {
				chequearDestino(3);
			}
		}
		
		//aqui chequeamos el pais, si es cero entonces es brasil, uno, estados unido etc, 
		void chequearDestino(int index){
			if(pais==0){
				txtPrecio.setText(String.valueOf(Tienda.preciosBr[index]));
			} else if(pais==1){
				txtPrecio.setText(String.valueOf(Tienda.preciosEUA[index]));
			}else if(pais==2){
				txtPrecio.setText(String.valueOf(Tienda.preciosMx[index]));
			} else if (pais==3) {
				txtPrecio.setText(String.valueOf(Tienda.preciosPr[index]));
			} else{
				txtPrecio.setText(String.valueOf(Tienda.preciosRu[index]));
			}
		}
	}

	
}
