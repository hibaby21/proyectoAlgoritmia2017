package proyecto.algoritmia;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.ActionEvent;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class DialogoVender extends JDialog implements ActionListener{

	private final JPanel contentPanel = new JPanel();
	private JButton btnNewButton;
	private JButton btnNewButton_1;
	private JLabel lblNewLabel;
	private JLabel lblNewLabel_2;
	private JLabel lblNewLabel_3;
	private JLabel lblNewLabel_4;
	private JComboBox cboTipoPasaje;
	private JComboBox cbotipoVuelo;
	private JTextField txtCantidad;
	private JTextField txtPrecio;
	private JScrollPane scrollPane;
	private JTextArea txtS;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			DialogoVender dialog = new DialogoVender();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public DialogoVender() {
		setBounds(100, 100, 450, 393);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		
		btnNewButton = new JButton("Vender");
		btnNewButton.addActionListener(this);
		btnNewButton.setBounds(335, 11, 89, 23);
		contentPanel.add(btnNewButton);
		
		btnNewButton_1 = new JButton("Cerrar");
		btnNewButton_1.setBounds(335, 45, 89, 23);
		contentPanel.add(btnNewButton_1);
		
		lblNewLabel = new JLabel("Tipo de pasaje");
		lblNewLabel.setBounds(10, 15, 104, 14);
		contentPanel.add(lblNewLabel);
		
		lblNewLabel_2 = new JLabel("Tipo de vuelo");
		lblNewLabel_2.setBounds(10, 84, 104, 14);
		contentPanel.add(lblNewLabel_2);
		
		lblNewLabel_3 = new JLabel("Cantidad");
		lblNewLabel_3.setBounds(10, 49, 104, 14);
		contentPanel.add(lblNewLabel_3);
		
		lblNewLabel_4 = new JLabel("Precio");
		lblNewLabel_4.setBounds(10, 119, 104, 14);
		contentPanel.add(lblNewLabel_4);
		
		cboTipoPasaje = new JComboBox();
		cboTipoPasaje.setModel(new DefaultComboBoxModel(new String[] {"Economico", "Economico Premium", "Negocios", "Primera Clase"}));
		cboTipoPasaje.setBounds(124, 12, 133, 20);
		cboTipoPasaje.addItemListener(new ItemHandler());
		contentPanel.add(cboTipoPasaje);
		
		cbotipoVuelo = new JComboBox();
		cbotipoVuelo.setModel(new DefaultComboBoxModel(new String[] {"Solo Ida", "Ida y Vuelta"}));
		cbotipoVuelo.setBounds(124, 81, 133, 20);
		cbotipoVuelo.addItemListener(new ItemHandler());
		contentPanel.add(cbotipoVuelo);
		
		txtCantidad = new JTextField();
		txtCantidad.setBounds(124, 46, 133, 20);
		contentPanel.add(txtCantidad);
		txtCantidad.setColumns(10);
		
		txtPrecio = new JTextField();
		txtPrecio.setEditable(false);
		txtPrecio.setBounds(124, 116, 133, 20);
		contentPanel.add(txtPrecio);
		txtPrecio.setColumns(10);
		txtPrecio.setText(String.valueOf(Tienda.precio0));
		
		scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 147, 414, 196);
		contentPanel.add(scrollPane);
		
		txtS = new JTextArea();
		txtS.setFont(new Font("monospaced", Font.PLAIN, 12));
		scrollPane.setViewportView(txtS);
	}
	public void actionPerformed(ActionEvent arg0) {
		if (arg0.getSource() == btnNewButton) {
			actionPerformedBtnNewButton(arg0);
		}
	}
	protected void actionPerformedBtnNewButton(ActionEvent arg0) {
		
	}
	
	protected void calcImpComp(){
		
	}
	
	protected void calcImpDscto(){
		
	}
	
	protected void calcImpPag(){
		
	}
	
	protected void mostrarResultados(){
		txtS.setText(String.format("%-20s", "Importe de compra") );
	}
	
	protected void imprimir(){
		
	}
	
	private class ItemHandler implements ItemListener{

		@Override
		public void itemStateChanged(ItemEvent e) {
			// TODO Auto-generated method stub
			if (e.getSource()==cboTipoPasaje) {
				if(cboTipoPasaje.getSelectedItem().equals("Economico")){
					if(cbotipoVuelo.getSelectedItem().equals("Solo Ida")){
						txtPrecio.setText(String.valueOf(Tienda.precio0));
					} else{
						txtPrecio.setText(String.valueOf((Tienda.precio0*2)-Tienda.precio0*0.10));
					}
				} else if(cboTipoPasaje.getSelectedItem().equals("Economico Premium")){
					if(cbotipoVuelo.getSelectedItem().equals("Solo Ida")){
						txtPrecio.setText(String.valueOf(Tienda.precio1));
					} else{
						txtPrecio.setText(String.valueOf((Tienda.precio1*2)-Tienda.precio1*0.10));
					}
				} else if(cboTipoPasaje.getSelectedItem().equals("Negocios")){
					if(cbotipoVuelo.getSelectedItem().equals("Solo Ida")){
						txtPrecio.setText(String.valueOf(Tienda.precio2));
					} else{
						txtPrecio.setText(String.valueOf((Tienda.precio2*2)-Tienda.precio2*0.10));
					}
				} else if(cboTipoPasaje.getSelectedItem().equals("Primera Clase")){
					if(cbotipoVuelo.getSelectedItem().equals("Solo Ida")){
						txtPrecio.setText(String.valueOf(Tienda.precio3));
					} else{
						txtPrecio.setText(String.valueOf((Tienda.precio3*2)-Tienda.precio3*0.10));
					}
				}
			}
			
			if(e.getSource()==cbotipoVuelo){
				if(cbotipoVuelo.getSelectedItem().equals("Solo Ida")){
					if(cboTipoPasaje.getSelectedItem().equals("Economico")){
						txtPrecio.setText(String.valueOf(Tienda.precio0));

					} else if(cboTipoPasaje.getSelectedItem().equals("Economico Premium")){
						txtPrecio.setText(String.valueOf(Tienda.precio1));

					} else if(cboTipoPasaje.getSelectedItem().equals("Negocios")){
						txtPrecio.setText(String.valueOf(Tienda.precio2));

					} else{
						txtPrecio.setText(String.valueOf(Tienda.precio3));

					}
				} else if(cbotipoVuelo.getSelectedItem().equals("Ida y Vuelta")){
					if(cboTipoPasaje.getSelectedItem().equals("Economico")){
						txtPrecio.setText(String.valueOf((Tienda.precio0*2)-Tienda.precio0*0.10));
						
					} else if(cboTipoPasaje.getSelectedItem().equals("Economico Premium")){
						txtPrecio.setText(String.valueOf((Tienda.precio1*2)-Tienda.precio1*0.10));

					} else if(cboTipoPasaje.getSelectedItem().equals("Negocios")){
						txtPrecio.setText(String.valueOf((Tienda.precio2*2)-Tienda.precio2*0.10));

					} else{
						txtPrecio.setText(String.valueOf((Tienda.precio3*2)-Tienda.precio3*0.10));

					}
				} 
			}
		}
		
	}

}
