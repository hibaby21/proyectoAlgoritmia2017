package proyecto.algoritmia;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import javax.swing.DefaultComboBoxModel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class DialogoModificar extends JDialog implements ActionListener, ItemListener {

	private final JPanel contentPanel = new JPanel();
	private JButton btnBorrar;
    private JComboBox cboTipoDeBoleto;
	private JComboBox cboDestino;
	private JLabel lblTipoDeBoleto;
	private JTextField txtPrecio;
	private JTextField txtCantMaletas;
	private JTextField txtCantPuntos;
	private JLabel lblNewLabel;
	private JLabel lblNewLabel_1;
	private JLabel lblNewLabel_2;
	private JButton btnGenerarAutomaticamente;
	private JButton btnGuardar;
	String guardarOMostrar="Mostrar";
	
	//Declaracion de variables 
	int tipoDeBoleto, destino;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			DialogoModificar dialog = new DialogoModificar();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public DialogoModificar() {
		setTitle("Modificar");
		setBounds(100, 100, 511, 300);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		{
			JLabel lblDestino = new JLabel("Destino");
			lblDestino.setBounds(10, 22, 91, 14);
			contentPanel.add(lblDestino);
		}
		
		btnBorrar = new JButton("Borrar");
		btnBorrar.addActionListener(this);
		btnBorrar.setBounds(396, 18, 89, 23);
		contentPanel.add(btnBorrar);
		
		cboTipoDeBoleto = new JComboBox();
		cboTipoDeBoleto.setModel(new DefaultComboBoxModel(new String[] {"Economico", "Economico Premium", "Negocios", "Primera"}));
		cboTipoDeBoleto.setBounds(132, 53, 115, 20);
		cboTipoDeBoleto.addItemListener(this);
		contentPanel.add(cboTipoDeBoleto);
		
		cboDestino = new JComboBox();
		cboDestino.setModel(new DefaultComboBoxModel(new String[] {"Brazil", "Estados Unidos", "Mexico", "Puerto Rico", "Rusia"}));
		cboDestino.setBounds(132, 19, 115, 20);
		cboDestino.addItemListener(this);
		contentPanel.add(cboDestino);
		
		lblTipoDeBoleto = new JLabel("TipoDeBoleto");
		lblTipoDeBoleto.setBounds(10, 56, 91, 14);
		contentPanel.add(lblTipoDeBoleto);
		
		txtPrecio = new JTextField();
		txtPrecio.setBounds(132, 90, 115, 20);
		contentPanel.add(txtPrecio);
		txtPrecio.setColumns(10);
		txtPrecio.setText(String.valueOf(Tienda.preciosDeBoletosBr[0]));
		
		txtCantMaletas = new JTextField();
		txtCantMaletas.setBounds(132, 122, 115, 20);
		contentPanel.add(txtCantMaletas);
		txtCantMaletas.setColumns(10);
		txtCantMaletas.setText(String.valueOf(Tienda.cantidadDeMaletasBr[0]));
		
		txtCantPuntos = new JTextField();
		txtCantPuntos.setBounds(132, 155, 115, 20);
		contentPanel.add(txtCantPuntos);
		txtCantPuntos.setColumns(10);
		txtCantPuntos.setText(String.valueOf(Tienda.cantidadDePuntosBr[0]));
		
		lblNewLabel = new JLabel("Precio");
		lblNewLabel.setBounds(10, 91, 46, 14);
		contentPanel.add(lblNewLabel);
		
		lblNewLabel_1 = new JLabel("Cantidad de maletas");
		lblNewLabel_1.setBounds(10, 125, 124, 14);
		contentPanel.add(lblNewLabel_1);
		
		lblNewLabel_2 = new JLabel("Puntos Ganados");
		lblNewLabel_2.setBounds(10, 158, 91, 14);
		contentPanel.add(lblNewLabel_2);
		
		btnGenerarAutomaticamente = new JButton("Generar Precios");
		btnGenerarAutomaticamente.setBounds(343, 87, 142, 23);
		contentPanel.add(btnGenerarAutomaticamente);
		
		btnGuardar = new JButton("Guardar");
		btnGuardar.addActionListener(this);
		btnGuardar.setBounds(396, 52, 89, 23);
		contentPanel.add(btnGuardar);
	}
	
	@Override
	public void actionPerformed(ActionEvent arg0) {
		if (arg0.getSource() == btnGuardar) {
			actionPerformedBtnGuardar(arg0);
		}
		if (arg0.getSource() == btnBorrar) {
			actionPerformedBtnBorrar(arg0);
		}
		// TODO Auto-generated method stub

		
	}

	protected void actionPerformedBtnBorrar(ActionEvent arg0) {
		
	}
	
	protected void actionPerformedBtnGuardar(ActionEvent arg0) {
		tipoDeBoleto =  cboTipoDeBoleto.getSelectedIndex();
		destino = cboDestino.getSelectedIndex();
		guardar();
	}
	
		@Override
		public void itemStateChanged(ItemEvent e) {
			// TODO Auto-generated method stub
			if (e.getSource()==cboTipoDeBoleto) {
				tipoDeBoleto =  cboTipoDeBoleto.getSelectedIndex();
				destino = cboDestino.getSelectedIndex();
				mostrar();
			}
		
			if (e.getSource()==cboDestino) {
				tipoDeBoleto =  cboTipoDeBoleto.getSelectedIndex();
				destino = cboDestino.getSelectedIndex();
				mostrar();
			}
			
			
		}
		
		//Aqui simplemente mostramos los cambios en los textfield de acuerdo a los cambios de los cbo
		void mostrar(){
			if(destino==0){
				txtPrecio.setText(String.valueOf(Tienda.preciosDeBoletosBr[tipoDeBoleto]));
				txtCantMaletas.setText(String.valueOf(Tienda.cantidadDeMaletasBr[tipoDeBoleto]));
				txtCantPuntos.setText(String.valueOf(Tienda.cantidadDePuntosBr[tipoDeBoleto]));
			} else if(destino==1){
				txtPrecio.setText(String.valueOf(Tienda.preciosDeBoletosEUA[tipoDeBoleto]));
				txtCantMaletas.setText(String.valueOf(Tienda.cantidadDeMaletasEUA[tipoDeBoleto]));
				txtCantPuntos.setText(String.valueOf(Tienda.cantidadDePuntosEUA[tipoDeBoleto]));
			}else if(destino==2){
				txtPrecio.setText(String.valueOf(Tienda.preciosDeBoletosMx[tipoDeBoleto]));
				txtCantMaletas.setText(String.valueOf(Tienda.cantidadDeMaletasMx[tipoDeBoleto]));
				txtCantPuntos.setText(String.valueOf(Tienda.cantidadDePuntosMx[tipoDeBoleto]));
			} else if (destino==3) {
				txtPrecio.setText(String.valueOf(Tienda.preciosDeBoletosPr[tipoDeBoleto]));
				txtCantMaletas.setText(String.valueOf(Tienda.cantidadDeMaletasPr[tipoDeBoleto]));
				txtCantPuntos.setText(String.valueOf(Tienda.cantidadDePuntosPr[tipoDeBoleto]));
			} else{
				txtPrecio.setText(String.valueOf(Tienda.preciosDeBoletosRu[tipoDeBoleto]));
				txtCantMaletas.setText(String.valueOf(Tienda.cantidadDeMaletasRu[tipoDeBoleto]));
				txtCantPuntos.setText(String.valueOf(Tienda.cantidadDePuntosRu[tipoDeBoleto]));
			}
		}

		//En este metodo guardamos en Tienda, todos los cambiar hechos a los precios, cantidad de maletas y puntos
		void guardar(){
			if(destino==0){
				Tienda.preciosDeBoletosBr[tipoDeBoleto]=Double.parseDouble(txtPrecio.getText());
				Tienda.cantidadDeMaletasBr[tipoDeBoleto]=Integer.parseInt(txtCantMaletas.getText());
				Tienda.cantidadDePuntosBr[tipoDeBoleto]= Integer.parseInt(txtCantPuntos.getText());
			} else if(destino==1){
				Tienda.preciosDeBoletosEUA[tipoDeBoleto]=Double.parseDouble(txtPrecio.getText());
				Tienda.cantidadDeMaletasEUA[tipoDeBoleto]=Integer.parseInt(txtCantMaletas.getText());
				Tienda.cantidadDePuntosEUA[tipoDeBoleto]= Integer.parseInt(txtCantPuntos.getText());
			}else if(destino==2){
				Tienda.preciosDeBoletosMx[tipoDeBoleto]=Double.parseDouble(txtPrecio.getText());
				Tienda.cantidadDeMaletasMx[tipoDeBoleto]=Integer.parseInt(txtCantMaletas.getText());
				Tienda.cantidadDePuntosMx[tipoDeBoleto]= Integer.parseInt(txtCantPuntos.getText());
			} else if (destino==3) {
				Tienda.preciosDeBoletosPr[tipoDeBoleto]=Double.parseDouble(txtPrecio.getText());
				Tienda.cantidadDeMaletasPr[tipoDeBoleto]=Integer.parseInt(txtCantMaletas.getText());
				Tienda.cantidadDePuntosPr[tipoDeBoleto]= Integer.parseInt(txtCantPuntos.getText());
			} else{
				Tienda.preciosDeBoletosRu[tipoDeBoleto]=Double.parseDouble(txtPrecio.getText());
				Tienda.cantidadDeMaletasRu[tipoDeBoleto]=Integer.parseInt(txtCantMaletas.getText());
				Tienda.cantidadDePuntosRu[tipoDeBoleto]= Integer.parseInt(txtCantPuntos.getText());
			}
		}

	
}
