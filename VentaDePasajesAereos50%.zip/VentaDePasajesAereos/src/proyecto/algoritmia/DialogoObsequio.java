package proyecto.algoritmia;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import javax.swing.DefaultComboBoxModel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class DialogoObsequio extends JDialog implements ActionListener {

	private final JPanel contentPanel = new JPanel();
	private JComboBox cboClase;
	private JTextField txtCantidad;
	private JTextField txtObsequio;
	private JButton btnAceptar;
	private JButton btnCancelar;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			DialogoObsequio dialog = new DialogoObsequio();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public DialogoObsequio() {
		setTitle("Configurar obsequio");
		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		{
			JLabel lblNewLabel = new JLabel("Clase");
			lblNewLabel.setBounds(10, 27, 105, 14);
			contentPanel.add(lblNewLabel);
		}
		{
			JLabel lblNewLabel_1 = new JLabel("Cantidad minima");
			lblNewLabel_1.setBounds(10, 61, 113, 14);
			contentPanel.add(lblNewLabel_1);
		}
		{
			JLabel lblNewLabel_2 = new JLabel("Obsequio");
			lblNewLabel_2.setBounds(10, 99, 105, 14);
			contentPanel.add(lblNewLabel_2);
		}
		
		cboClase = new JComboBox();
		cboClase.setModel(new DefaultComboBoxModel(new String[] {"Economica", "Ecom. Premium", "Negocios", "Primera"}));
		cboClase.setBounds(123, 24, 105, 20);
		contentPanel.add(cboClase);
		//Obtenemos el numero asignado a la variable modelo obsequiable y le decimos al cbo que ese numero es el index que debe mostrar
		cboClase.setSelectedIndex(Tienda.modeloObsequiable);
		
		txtCantidad = new JTextField();
		txtCantidad.setBounds(123, 58, 105, 20);
		contentPanel.add(txtCantidad);
		txtCantidad.setColumns(10);
		//Obtenemos el numero asignado a la variable cantidadminimaobsequiable, este numero lo transformamos a string y lo asignamos a la caja de texto txtCantidad
		txtCantidad.setText(String.valueOf(Tienda.cantidadMinimaObsequiable));
		
		txtObsequio = new JTextField();
		txtObsequio.setBounds(123, 96, 201, 20);
		contentPanel.add(txtObsequio);
		txtObsequio.setColumns(10);
		//obtenemos el string asignado a la variable obsequio y se lo asignamos a la caja de texto tctObsequio
		txtObsequio.setText(Tienda.obsequio);
		
		btnAceptar = new JButton("Aceptar");
		btnAceptar.addActionListener(this);
		btnAceptar.setBounds(335, 23, 89, 23);
		contentPanel.add(btnAceptar);
		
		btnCancelar = new JButton("Cancelar");
		btnCancelar.addActionListener(this);
		btnCancelar.setBounds(335, 57, 89, 23);
		contentPanel.add(btnCancelar);
	}
	public void actionPerformed(ActionEvent arg0) {
		if (arg0.getSource() == btnCancelar) {
			actionPerformedBtnCancelar(arg0);
		}
		if (arg0.getSource() == btnAceptar) {
			actionPerformedBtnNewButton(arg0);
		}
	}
	
	//En este metodo almacenamos los cambios hechos en el cbo, la caja de texto para la cantidad minimia y la del obsequio
	protected void actionPerformedBtnNewButton(ActionEvent arg0) {
		Tienda.modeloObsequiable=cboClase.getSelectedIndex();
		Tienda.cantidadMinimaObsequiable=Integer.parseInt(txtCantidad.getText());
		Tienda.obsequio = txtObsequio.getText();
	}
	
	//Cerramos el dialogo
	protected void actionPerformedBtnCancelar(ActionEvent arg0) {
		dispose();
	}
}
