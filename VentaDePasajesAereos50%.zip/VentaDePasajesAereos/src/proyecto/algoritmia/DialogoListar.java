package proyecto.algoritmia;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JScrollPane;
import javax.swing.ScrollPaneConstants;
import javax.swing.JTextArea;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class DialogoListar extends JDialog implements ActionListener {

	private final JPanel contentPanel = new JPanel();
	private JScrollPane scrollPane;
	private JTextArea txtS;
	private JButton btnNewButton;
	private JButton btnNewButton_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			DialogoListar dialog = new DialogoListar();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public DialogoListar() {
		setBounds(100, 100, 533, 348);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		
		scrollPane = new JScrollPane();
		scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
		scrollPane.setBounds(10, 11, 507, 250);
		contentPanel.add(scrollPane);
		txtS = new JTextArea();
		txtS.setColumns(4);
		txtS.setForeground(Color.BLACK);
		txtS.setFont(new Font("monospaced", Font.PLAIN, 12));
		scrollPane.setViewportView(txtS);
		
		btnNewButton = new JButton("Cerrar");
		btnNewButton.addActionListener(this);
		btnNewButton.setBounds(158, 275, 89, 23);
		contentPanel.add(btnNewButton);
		
		btnNewButton_1 = new JButton("Listar");
		btnNewButton_1.setBounds(268, 275, 89, 23);
		contentPanel.add(btnNewButton_1);
		
		imprimir();
	}
	
	// En este metodo listamos cada tipo de boletos y sus caracteristicas, por ejemplo precio, cantdiad de maletas y puntos
	void imprimir(){

		String[] tipoDeBoletos = {" Boletos Economicos"," Boletos Econ. Premium"," Boletos de Negocios"," Boletos Primera Clase"};
		txtS.setText(" \n"+" LISTADO DE PASAJES" + "\n\n");
		
		//Haremos el ciclo 4 veces porque solo tenemos 4 tipos de boletos, para cada tipo de boleto se mostrara sus caracteristicas
		for(int contador = 0; contador<4;contador++){
			//Aqui imprimimos el tipo del boleto
			txtS.append(tipoDeBoletos[contador] + "\n");
			//Aqui imprimimos los destinos horizontalmente
			txtS.append(String.format("%-23s %-10s %-10s %-10s %-15s %-15s" , " Destinos", "Brasil", "EUA", "Mexico", "Puerto Rico", "Rusia")+ "\n");
			//Aqui imprimimos los precios de cada pais horizontalmente
			txtS.append(String.format("%-23s %-10s %-10s %-10s %-15s %-15s" , " Precio", Tienda.preciosDeBoletosBr[contador], Tienda.preciosDeBoletosEUA[contador], Tienda.preciosDeBoletosMx[contador], Tienda.preciosDeBoletosPr[contador],Tienda.preciosDeBoletosRu[contador]) + "\n");
			//Aqui imprimimos la cantidad de maletas de cada pais horizontalmente
			txtS.append(String.format("%-23s %-10s %-10s %-10s %-15s %-15s" , " N� de maletas", Tienda.cantidadDeMaletasBr[contador], Tienda.cantidadDeMaletasEUA[contador], Tienda.cantidadDeMaletasMx[contador], Tienda.cantidadDeMaletasPr[contador],Tienda.cantidadDeMaletasRu[contador]) + "\n");
			//Aqui imprimimos los cantidad de puntos que otorga cada pais horizontalmente
			txtS.append(String.format("%-23s %-10s %-10s %-10s %-15s %-15s" , " Puntos", Tienda.cantidadDePuntosBr[contador], Tienda.cantidadDePuntosEUA[contador], Tienda.cantidadDePuntosMx[contador], Tienda.cantidadDePuntosPr[contador],Tienda.cantidadDePuntosRu[contador])+ "\n\n");

		}
	}
	
	
	
	
	public void actionPerformed(ActionEvent arg0) {
		if (arg0.getSource() == btnNewButton) {
			actionPerformedBtnNewButton(arg0);
		}
	}
	protected void actionPerformedBtnNewButton(ActionEvent arg0) {
	}
}
