package proyecto.algoritmia;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.text.BadLocationException;
import javax.swing.JLabel;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.text.DecimalFormat;
import java.awt.event.ActionEvent;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.ScrollPaneConstants;

public class DialogoVender extends JDialog implements ActionListener, ItemListener{

	private final JPanel contentPanel = new JPanel();
	private JButton btnVender;
	private JButton btnCerrar;
	private JLabel lblNewLabel;
	private JLabel lblNewLabel_3;
	private JLabel lblNewLabel_4;
	private JComboBox cboTipoDeBoleto;
	private JTextField txtCantPas;
	private JTextField txtPrecio;
	private JScrollPane scrollPane;
	private JLabel lblNewLabel_1;
	private JComboBox cboDestino;
	
	//Declarar Variables
	double impComp, impDscto, impPag, precioDelPasaje;
	int cantidadDePasajes, tipoDeBoleto,destino, cliente;
	String boleto, obsequio, premioSorpresa;
	private JTextArea txtS;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			DialogoVender dialog = new DialogoVender();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public DialogoVender() {
		setTitle("Vender");
		setBounds(100, 100, 450, 425);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		
		btnVender = new JButton("Vender");
		btnVender.addActionListener(this);
		btnVender.setBounds(335, 11, 89, 23);
		contentPanel.add(btnVender);
		
		btnCerrar = new JButton("Cerrar");
		btnCerrar.addActionListener(this);
		btnCerrar.setBounds(335, 45, 89, 23);
		contentPanel.add(btnCerrar);
		
		lblNewLabel = new JLabel("Tipo de boleto");
		lblNewLabel.setBounds(10, 84, 104, 14);
		contentPanel.add(lblNewLabel);
		
		lblNewLabel_3 = new JLabel("Cantidad");
		lblNewLabel_3.setBounds(10, 49, 104, 14);
		contentPanel.add(lblNewLabel_3);
		
		lblNewLabel_4 = new JLabel("Precio");
		lblNewLabel_4.setBounds(10, 118, 104, 14);
		contentPanel.add(lblNewLabel_4);
		
		cboTipoDeBoleto = new JComboBox();
		cboTipoDeBoleto.setModel(new DefaultComboBoxModel(new String[] {"Economico", "Economico Premium", "Negocios", "Primera"}));
		cboTipoDeBoleto.setBounds(124, 81, 133, 20);
		//Aqui decimos que esta es la clase que escuchara a los cambios del combobox
		cboTipoDeBoleto.addItemListener(this);
		contentPanel.add(cboTipoDeBoleto);
		
		txtCantPas = new JTextField();
		txtCantPas.addActionListener(this);
		txtCantPas.setBounds(124, 46, 133, 20);
		contentPanel.add(txtCantPas);
		txtCantPas.setColumns(10);
		txtCantPas.setText("1");

		
		txtPrecio = new JTextField();
		txtPrecio.setEditable(false);
		txtPrecio.setBounds(124, 115, 133, 20);
		contentPanel.add(txtPrecio);
		txtPrecio.setText(String.valueOf(Tienda.preciosDeBoletosBr[0]));
		txtPrecio.setColumns(10);
		
		
		scrollPane = new JScrollPane();
		scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
		scrollPane.setBounds(10, 152, 414, 223);
		contentPanel.add(scrollPane);
		
		txtS = new JTextArea();
		txtS.setFont(new Font("monospaced", Font.PLAIN, 12));
		scrollPane.setViewportView(txtS);
		
		lblNewLabel_1 = new JLabel("Destino");
		lblNewLabel_1.setBounds(10, 15, 46, 14);
		contentPanel.add(lblNewLabel_1);
		
		cboDestino = new JComboBox();
		cboDestino.setModel(new DefaultComboBoxModel(new String[] {"Brasil", "Estados Unidos", "Mexico", "Puerto Rico", "Rusia"}));
		cboDestino.setBounds(124, 12, 133, 20);
		//Aqui decimos que esta es la clase que escuchara a los cambios del combobox
		cboDestino.addItemListener(this);
		contentPanel.add(cboDestino);
	}
	
	//Eate metodo escuchara a los cambios de los combobox
	@Override
	public void itemStateChanged(ItemEvent e) {
		
		if (e.getSource()==cboTipoDeBoleto) {
			tipoDeBoleto = cboTipoDeBoleto.getSelectedIndex();
			destino = cboDestino.getSelectedIndex();
			mostrar();
		}
		
		if (e.getSource()==cboDestino) {
			tipoDeBoleto = cboTipoDeBoleto.getSelectedIndex();
			destino = cboDestino.getSelectedIndex();
			mostrar();
		}
	}
	
	public void actionPerformed(ActionEvent arg0) {
		if (arg0.getSource() == txtCantPas) {
		}
		if (arg0.getSource() == btnCerrar) {
			actionPerformedBtnCerrar(arg0);
		}
		if (arg0.getSource() == btnVender) {
			actionPerformedBtnVender(arg0);
		}
	}
	protected void actionPerformedBtnVender(ActionEvent arg0) {
		//La variable cliente aumenta su valor cada vez que procesamos un compra
		cliente++;
	
		tipoDeBoleto = cboTipoDeBoleto.getSelectedIndex();
		precioDelPasaje = Double.parseDouble(txtPrecio.getText());
		destino = cboDestino.getSelectedIndex();
		cantidadDePasajes = Integer.parseInt(txtCantPas.getText());
		
		calcTipoDeBoleto();
		calcImpComp();
		calcImpDscto();
		calcImpPag();
		calcObsequio();
		calcPremioSorpresa();
		mostrarResultados();
		efectuarIncrementos();

		
	}
	
	protected void actionPerformedBtnCerrar(ActionEvent arg0) {
		dispose();
	}
	
	//Cambiamos el precio de txtPrecio
	void mostrar(){
		if(destino==0){
			txtPrecio.setText(String.valueOf(Tienda.preciosDeBoletosBr[tipoDeBoleto]));
		} else if(destino==1){
			txtPrecio.setText(String.valueOf(Tienda.preciosDeBoletosEUA[tipoDeBoleto]));
		}else if(destino==2){
			txtPrecio.setText(String.valueOf(Tienda.preciosDeBoletosMx[tipoDeBoleto]));
		} else if (destino==3) {
			txtPrecio.setText(String.valueOf(Tienda.preciosDeBoletosPr[tipoDeBoleto]));
		} else{
			txtPrecio.setText(String.valueOf(Tienda.preciosDeBoletosRu[tipoDeBoleto]));
		}
	}
	
	//En este metodo aumentamos la cantidad de comprar efectuadas de cada clase y tambien cuantos pasajes se an comprado
	protected void efectuarIncrementos(){
		switch (tipoDeBoleto) {
		case 0:
			Tienda.cantDeVentasEconomicas = Tienda.cantDeVentasEconomicas + 1;
			Tienda.cantPasajesVendidosEconomicos = Tienda.cantPasajesVendidosEconomicos + cantidadDePasajes;
			Tienda.impTotalBoletosEcon = Tienda.impTotalBoletosEcon + impPag;
			break;
		case 1:
			Tienda.cantDeVentasEconPremium = Tienda.cantDeVentasEconPremium + 1;
			Tienda.cantPasajesVendidosEconPremium = Tienda.cantPasajesVendidosEconPremium + cantidadDePasajes;
			Tienda.impTotalBoletosEconPremium = Tienda.impTotalBoletosEconPremium + impPag;
			break;
		case 2:
			Tienda.cantDeVentasNegocios = Tienda.cantDeVentasNegocios + 1;
			Tienda.cantPasajesVendidosNegocios = Tienda.cantPasajesVendidosNegocios + cantidadDePasajes;
			Tienda.impTotalBoletosNegocios = Tienda.impTotalBoletosNegocios + impPag;
			break;
		case 3:
			Tienda.cantDeVentasPrimera = Tienda.cantDeVentasPrimera + 1;
			Tienda.cantPasajesVendidosPrimera = Tienda.cantPasajesVendidosPrimera + cantidadDePasajes;
			Tienda.impTotalBoletosPrimera = Tienda.impTotalBoletosPrimera + impPag;
			break;

		default:
			break;
		}
	}
	
	//Aqui se guardara el tipo de boleto pero de modo string para pder imprimirlo
	protected void calcTipoDeBoleto(){
		switch (tipoDeBoleto) {
		case 0:
			boleto = "Economica";
			break;
		case 1:
			boleto = "Economica Premium";
			break;
		case 2:
			boleto = "Negocios";
			break;
		case 3:
			boleto = "Primera";
			break;
		default:
			break;
		}
	}
	
	// Calculando el obsequio
	protected void calcObsequio(){
		if (tipoDeBoleto==Tienda.modeloObsequiable&&cantidadDePasajes>=Tienda.cantidadMinimaObsequiable) {
			obsequio = Tienda.obsequio;
		} else{
			obsequio = "Ninguno";
		}
	}
	
	//Caldulando el premio sorpresa
	protected void calcPremioSorpresa(){
		if (cliente==Tienda.numeroClienteSorpresa) {
			premioSorpresa = Tienda.premioSorpresa;
		} else{
			premioSorpresa = "Ninguno";
		}
	}
	
	//Calculando el importe de compra
	protected void calcImpComp(){
		impComp = precioDelPasaje * cantidadDePasajes;
	}
	
	//Calculando el importe de descuento
	protected void calcImpDscto(){
		if (cantidadDePasajes<5) {
			impDscto = impComp * Tienda.porcentaje1;
		} else if (cantidadDePasajes < 10) {
			impDscto = impComp * Tienda.porcentaje2;
		} else if (cantidadDePasajes < 15) {
			impDscto = impComp * Tienda.porcentaje3;
		} else{
			impDscto = impComp * Tienda.porcentaje4;
		}
	}
	
	//Calcular el importe a pagar
	protected void calcImpPag(){
		impPag = impComp - impDscto;
	}
	
	protected void mostrarResultados(){
		txtS.setText(String.format("%-20s", "Tipo de Boleto") + " : " + boleto + "\n" );
		imprimir(String.format("%-20s", "Precio de cada pasaje") + " : " + precioDelPasaje);
		imprimir(String.format("%-20s", "Pasajes comprados") + " : " + cantidadDePasajes);
		imprimir(String.format("%-20s", "Importe de compra") + " : " + impComp);
		imprimir(String.format("%-20s", "Importe de descuento") + " : " + impDscto);
		imprimir(String.format("%-20s", "Importe de pago") + " : " + impPag);
		imprimir(String.format("%-20s", "Obsequio") + " : " + obsequio);
		imprimir(String.format("%-20s", "Premio Sorpresa") + " : " + premioSorpresa);

	}
	
	protected void imprimir(String cad){
		txtS.append(cad + "\n");
	}
}
