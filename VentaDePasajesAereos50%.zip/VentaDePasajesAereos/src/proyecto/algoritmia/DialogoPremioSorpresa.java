package proyecto.algoritmia;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class DialogoPremioSorpresa extends JDialog implements ActionListener {

	private final JPanel contentPanel = new JPanel();
	private JTextField txtNumCliente;
	private JTextField txtPremio;
	private JButton btnAceptar;
	private JButton btnCancelar;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			DialogoPremioSorpresa dialog = new DialogoPremioSorpresa();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public DialogoPremioSorpresa() {
		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		{
			JLabel lblNewLabel = new JLabel("Numero de cliente");
			lblNewLabel.setBounds(10, 25, 103, 14);
			contentPanel.add(lblNewLabel);
		}
		{
			JLabel lblNewLabel_1 = new JLabel("Premio sorpresa");
			lblNewLabel_1.setBounds(10, 60, 103, 14);
			contentPanel.add(lblNewLabel_1);
		}
		{
			txtNumCliente = new JTextField();
			txtNumCliente.setBounds(123, 22, 86, 20);
			contentPanel.add(txtNumCliente);
			txtNumCliente.setColumns(10);
			txtNumCliente.setText(String.valueOf(Tienda.numeroClienteSorpresa));
		}
		{
			txtPremio = new JTextField();
			txtPremio.setBounds(123, 57, 86, 20);
			contentPanel.add(txtPremio);
			txtPremio.setColumns(10);
			txtPremio.setText(Tienda.premioSorpresa);
		}
		{
			btnAceptar = new JButton("Aceptar");
			btnAceptar.addActionListener(this);
			btnAceptar.setBounds(335, 21, 89, 23);
			contentPanel.add(btnAceptar);
		}
		{
			btnCancelar = new JButton("Cancelar");
			btnCancelar.addActionListener(this);
			btnCancelar.setBounds(335, 56, 89, 23);
			contentPanel.add(btnCancelar);
		}
	}

	public void actionPerformed(ActionEvent arg0) {
		if (arg0.getSource() == btnCancelar) {
			actionPerformedBtnCancelar(arg0);
		}
		if (arg0.getSource() == btnAceptar) {
			actionPerformedBtnAceptar(arg0);
		}
	}
	
	//Almacenamos el numero del cliente sorpresa y el premio sorpresa
	protected void actionPerformedBtnAceptar(ActionEvent arg0) {
		Tienda.numeroClienteSorpresa=Integer.parseInt(txtNumCliente.getText());
		Tienda.premioSorpresa = txtPremio.getText();
	}
	protected void actionPerformedBtnCancelar(ActionEvent arg0) {
		dispose();
	}
}
