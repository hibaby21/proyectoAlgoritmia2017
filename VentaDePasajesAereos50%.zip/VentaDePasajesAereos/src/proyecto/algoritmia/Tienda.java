package proyecto.algoritmia;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import java.awt.Color;

public class Tienda extends JFrame implements ActionListener {

	private JPanel contentPane;
	private JMenuBar menuBar;
	private JMenu mnNewMenu;
	private JMenuItem salir;
	private JMenu mnNewMenu_1;
	private JMenu mnNewMenu_2;
	private JMenu mnNewMenu_3;
	private JMenu mnNewMenu_4;
	private JMenuItem mntmNewMenuItem;
	private JMenuItem mntmNewMenuItem_1;
	private JMenuItem mntmNewMenuItem_2;
	private JMenuItem mntmNewMenuItem_3;
	private JMenuItem mntmNewMenuItem_4;
	private JMenuItem mntmNewMenuItem_5;
	private JMenuItem mntmNewMenuItem_6;
	private JMenuItem mntmNewMenuItem_7;
	private JMenuItem mntmNewMenuItem_8;
	private JMenuItem mntmNewMenuItem_9;
	
	//Precios para cada uno de los destino almacenados en el siguiente ordern: economico, econ, premium, negocios y primera
	static Double[] preciosDeBoletosBr = {600.00,680.00,799.00,999.00};
	static Double[] preciosDeBoletosEUA ={650.00,700.00,850.00,1050.00};
	static Double[] preciosDeBoletosMx = {620.00,700.00,820.00,1020.00};
	static Double[] preciosDeBoletosPr = {500.00,550.00,700.00,900.00};
	static Double[] preciosDeBoletosRu = {1000.00,1100.00,1350.00,1700.00};
	
	// Declarando la cantidad de maletas a cada uno de los paises, el orden es economico, economicp premium, negocios,primera
	static int[] cantidadDeMaletasBr = {2,2,2,2};
	static int[] cantidadDeMaletasEUA= {2,2,2,2};
	static int[] cantidadDeMaletasMx = {2,2,2,2};
	static int[] cantidadDeMaletasPr = {2,2,2,2};
	static int[] cantidadDeMaletasRu = {2,2,2,2};
	
	// Declaracion de cantidad de puntos ganados, economico economico premium etc
	static int[] cantidadDePuntosBr = {100,200,300,400};
	static int[] cantidadDePuntosEUA ={150,250,350,450};
	static int[] cantidadDePuntosMx = {125,225,325,425};
	static int[] cantidadDePuntosPr = {80,160,250,350};
	static int[] cantidadDePuntosRu = {200,300,400,500};
	
	//Cantidad de ventas procesadas en la clase economica
	public static int cantDeVentasEconomicas = 0;
	//cantidad de pasajes vendidos en la clase economica
	public static int cantPasajesVendidosEconomicos = 0;
	// el importe total en la clase economica, multiplicando la cantidad de pasajes por el precio
	public static double impTotalBoletosEcon= 0.00;
	
	public static int cantDeVentasEconPremium = 0;
	public static int cantPasajesVendidosEconPremium = 0;
	public static double impTotalBoletosEconPremium= 0.00;
	
	public static int cantDeVentasNegocios = 0;
	public static int cantPasajesVendidosNegocios= 0;
	public static double impTotalBoletosNegocios= 0.00;
	
	public static int cantDeVentasPrimera = 0;
	public static int cantPasajesVendidosPrimera = 0;
	public static double impTotalBoletosPrimera= 0.00;
	
	//Importe total general es igual a la suma de los importe generados en cada clase
	public static double impTotalGeneral = impTotalBoletosEcon+impTotalBoletosEconPremium+impTotalBoletosNegocios+impTotalBoletosPrimera; 
	 
	// Porcentajes de descuento de acuerdo a la cantidad de pasajes cmprados
	public static double porcentaje1 = 0.05; 
	public static double porcentaje2 = 0.10; 
	public static double porcentaje3 = 0.15; 
	public static double porcentaje4 = 0.20; 
	 
	// Cantidad �ptima de pasajes vendidos
	public static int cantidadOptima = 4000; 
	 
	// Modelo para el cual se otorga el obsequio, 0 significa el elemento 0 del combobox donde se selecciona la clase
	public static int modeloObsequiable = 0; 
	 
	// Cantidad m�nima de pasajes adquiridas para obtener el obsequio 
	public static int cantidadMinimaObsequiable = 4;  
	// Obsequio 
	public static String obsequio = "S/.300 de credito para hospedarse en cualquier hotel"; 
	 
	// N�mero de cliente que recibe el premio sorpresa
	public static int numeroClienteSorpresa = 7; 
	 
	// Premio sorpresa
	public static String premioSorpresa = "Netflix gratis por 6 meses"; 
	private JLabel lblNewLabel;
	private JLabel lblNewLabel_1;
	private JPasswordField txtContrase�a;
	private JTextField txtUsuario;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Tienda frame = new Tienda();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Tienda() {
		setTitle("Teinda Principal");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		
		menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		mnNewMenu = new JMenu("Archivo");
		menuBar.add(mnNewMenu);
		
		salir = new JMenuItem("Salir");
		salir.addActionListener(this);
		mnNewMenu.add(salir);
		
		mnNewMenu_1 = new JMenu("Mantenimiento");
		menuBar.add(mnNewMenu_1);
		
		mntmNewMenuItem = new JMenuItem("Consultar pasajes");
		mntmNewMenuItem.addActionListener(this);
		mnNewMenu_1.add(mntmNewMenuItem);
		
		mntmNewMenuItem_1 = new JMenuItem("Modificar pasajes");
		mntmNewMenuItem_1.addActionListener(this);
		mnNewMenu_1.add(mntmNewMenuItem_1);
		
		mntmNewMenuItem_2 = new JMenuItem("Listar pasajes");
		mntmNewMenuItem_2.addActionListener(this);
		mnNewMenu_1.add(mntmNewMenuItem_2);
		
		mnNewMenu_2 = new JMenu("Ventas");
		menuBar.add(mnNewMenu_2);
		
		mntmNewMenuItem_3 = new JMenuItem("Vender");
		mntmNewMenuItem_3.addActionListener(this);
		mnNewMenu_2.add(mntmNewMenuItem_3);
		
		mntmNewMenuItem_4 = new JMenuItem("Generar reportes");
		mntmNewMenuItem_4.addActionListener(this);
		mnNewMenu_2.add(mntmNewMenuItem_4);
		
		mnNewMenu_3 = new JMenu("Configuraci\u00F3n");
		menuBar.add(mnNewMenu_3);
		
		mntmNewMenuItem_5 = new JMenuItem("Configurar descuentos");
		mntmNewMenuItem_5.addActionListener(this);
		mnNewMenu_3.add(mntmNewMenuItem_5);
		
		mntmNewMenuItem_6 = new JMenuItem("Configurar obsequio");
		mntmNewMenuItem_6.addActionListener(this);
		mnNewMenu_3.add(mntmNewMenuItem_6);
		
		mntmNewMenuItem_7 = new JMenuItem("Configurar cantidad \u00F3ptima de pasajes vendidos");
		mntmNewMenuItem_7.addActionListener(this);
		mnNewMenu_3.add(mntmNewMenuItem_7);
		
		mntmNewMenuItem_8 = new JMenuItem("Configurar premio sorpresa");
		mntmNewMenuItem_8.addActionListener(this);
		mnNewMenu_3.add(mntmNewMenuItem_8);
		
		mnNewMenu_4 = new JMenu("Ayuda");
		menuBar.add(mnNewMenu_4);
		
		mntmNewMenuItem_9 = new JMenuItem("Acerca de Tienda");
		mnNewMenu_4.add(mntmNewMenuItem_9);
		contentPane = new JPanel();
		contentPane.setBackground(Color.YELLOW);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		lblNewLabel = new JLabel("Usuario");
		lblNewLabel.setBounds(87, 72, 46, 14);
		contentPane.add(lblNewLabel);
		
		lblNewLabel_1 = new JLabel("Contrase\u00F1a");
		lblNewLabel_1.setBounds(87, 115, 86, 14);
		contentPane.add(lblNewLabel_1);
		
		txtContrase�a = new JPasswordField();
		txtContrase�a.setBounds(176, 112, 86, 20);
		contentPane.add(txtContrase�a);
		
		txtUsuario = new JTextField();
		txtUsuario.setBounds(176, 69, 86, 20);
		contentPane.add(txtUsuario);
		txtUsuario.setColumns(10);
	}
	public void actionPerformed(ActionEvent arg0) {
		if (arg0.getSource() == salir) {
			actionPerformedSalir(arg0);
		}
		if (arg0.getSource() == mntmNewMenuItem_8) {
			actionPerformedMntmNewMenuItem_8(arg0);
		}
		if (arg0.getSource() == mntmNewMenuItem_7) {
			actionPerformedMntmNewMenuItem_7(arg0);
		}
		if (arg0.getSource() == mntmNewMenuItem_6) {
			actionPerformedMntmNewMenuItem_6(arg0);
		}
		if (arg0.getSource() == mntmNewMenuItem_5) {
			actionPerformedMntmNewMenuItem_5(arg0);
		}
		if (arg0.getSource() == mntmNewMenuItem_2) {
			actionPerformedMntmNewMenuItem_2(arg0);
		}
		if (arg0.getSource() == mntmNewMenuItem_4) {
			actionPerformedMntmNewMenuItem_4(arg0);
		}
		if (arg0.getSource() == mntmNewMenuItem) {
			actionPerformedMntmNewMenuItem(arg0);
		}
		if (arg0.getSource() == mntmNewMenuItem_1) {
			actionPerformedMntmNewMenuItem_1(arg0);
		}
		if (arg0.getSource() == mntmNewMenuItem_3) {
			actionPerformedMntmNewMenuItem_3(arg0);
		}
	}
	protected void actionPerformedMntmNewMenuItem_3(ActionEvent arg0) {
		DialogoVender dialogoVender = new DialogoVender();
		dialogoVender.setLocationRelativeTo(this);
		dialogoVender.setVisible(true);
	}
	protected void actionPerformedMntmNewMenuItem_1(ActionEvent arg0) {
		DialogoModificar dialogoModificar = new DialogoModificar();
		dialogoModificar.setLocationRelativeTo(this);
		dialogoModificar.setVisible(true);
	}
	protected void actionPerformedMntmNewMenuItem(ActionEvent arg0) {
		DialogoConsultar dialogoConsultar= new DialogoConsultar();
		dialogoConsultar.setLocationRelativeTo(this);
		dialogoConsultar.setVisible(true);
	}
	protected void actionPerformedMntmNewMenuItem_4(ActionEvent arg0) {
		DialogoReportes dialogoReportes = new DialogoReportes();
		dialogoReportes.setLocationRelativeTo(this);
		dialogoReportes.setVisible(true);
	}
	protected void actionPerformedMntmNewMenuItem_2(ActionEvent arg0) {
		DialogoListar dialogoListar = new DialogoListar();
		dialogoListar.setLocationRelativeTo(this);
		dialogoListar.setVisible(true);
	}
	protected void actionPerformedMntmNewMenuItem_5(ActionEvent arg0) {
		DialogoDescuentos dialogoDescuentos = new DialogoDescuentos();
		dialogoDescuentos.setLocationRelativeTo(this);
		dialogoDescuentos.setVisible(true);
	}
	protected void actionPerformedMntmNewMenuItem_6(ActionEvent arg0) {
		DialogoObsequio dialogoObsequio = new DialogoObsequio();
		dialogoObsequio.setLocationRelativeTo(this);
		dialogoObsequio.setVisible(true);
	}
	protected void actionPerformedMntmNewMenuItem_7(ActionEvent arg0) {
		DialogoCantidadOptima dialogoCantidadOptima = new DialogoCantidadOptima();
		dialogoCantidadOptima.setLocationRelativeTo(this);
		dialogoCantidadOptima.setVisible(true);
	}
	protected void actionPerformedMntmNewMenuItem_8(ActionEvent arg0) {
		DialogoPremioSorpresa dialogoPremioSorpresa = new DialogoPremioSorpresa();
		dialogoPremioSorpresa.setLocationRelativeTo(this);
		dialogoPremioSorpresa.setVisible(true);
	}
	protected void actionPerformedSalir(ActionEvent arg0) {
		System.exit(0);
	}
}
