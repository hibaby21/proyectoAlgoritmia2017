package proyecto.algoritmia;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.text.DecimalFormat;
import java.awt.event.ActionEvent;

public class DialogoDescuentos extends JDialog implements ActionListener {

	private final JPanel contentPanel = new JPanel();
	private JLabel lblNewLabel;
	private JLabel lblNewLabel_1;
	private JLabel lblNewLabel_2;
	private JLabel lblNewLabel_3;
	private JTextField txtPrimerPorcentaje;
	private JTextField txtSegundoDescuento;
	private JTextField txtTecerDescuento;
	private JTextField txtCuartoDescuento;
	private JLabel lblNewLabel_4;
	private JLabel lblNewLabel_5;
	private JLabel lblNewLabel_6;
	private JLabel lblNewLabel_7;
	private JButton btnAceptar;
	private JButton btnCancelar;
	
	DecimalFormat df = new DecimalFormat("0.00");

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			DialogoDescuentos dialog = new DialogoDescuentos();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public DialogoDescuentos() {
		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		
		lblNewLabel = new JLabel("1 a 4 pasajes");
		lblNewLabel.setBounds(10, 28, 108, 14);
		contentPanel.add(lblNewLabel);
		
		lblNewLabel_1 = new JLabel("5 a 9 pasajes");
		lblNewLabel_1.setBounds(10, 63, 108, 14);
		contentPanel.add(lblNewLabel_1);
		
		lblNewLabel_2 = new JLabel("10 a 14 pasajes");
		lblNewLabel_2.setBounds(10, 99, 108, 14);
		contentPanel.add(lblNewLabel_2);
		
		lblNewLabel_3 = new JLabel("Mas de 15 pasajes");
		lblNewLabel_3.setBounds(10, 135, 108, 14);
		contentPanel.add(lblNewLabel_3);
		
		txtPrimerPorcentaje = new JTextField();
		txtPrimerPorcentaje.setBounds(124, 25, 86, 20);
		contentPanel.add(txtPrimerPorcentaje);
		txtPrimerPorcentaje.setColumns(10);
		//Obtenemos el porcentaje, lo multiplicamos por 100 y le damos un limite de 2 decimales, luego lo asignamos a la caja de texto
		txtPrimerPorcentaje.setText(df.format(Tienda.porcentaje1*100));
		
		txtSegundoDescuento = new JTextField();
		txtSegundoDescuento.setBounds(124, 60, 86, 20);
		contentPanel.add(txtSegundoDescuento);
		txtSegundoDescuento.setColumns(10);
		txtSegundoDescuento.setText(df.format(Tienda.porcentaje2*100));
		
		txtTecerDescuento = new JTextField();
		txtTecerDescuento.setBounds(124, 96, 86, 20);
		contentPanel.add(txtTecerDescuento);
		txtTecerDescuento.setColumns(10);
		txtTecerDescuento.setText(df.format(Tienda.porcentaje1*300));
		
		txtCuartoDescuento = new JTextField();
		txtCuartoDescuento.setBounds(124, 132, 86, 20);
		contentPanel.add(txtCuartoDescuento);
		txtCuartoDescuento.setColumns(10);
		txtCuartoDescuento.setText(df.format(Tienda.porcentaje4*100));
		
		lblNewLabel_4 = new JLabel("%");
		lblNewLabel_4.setBounds(220, 28, 46, 14);
		contentPanel.add(lblNewLabel_4);
		
		lblNewLabel_5 = new JLabel("%");
		lblNewLabel_5.setBounds(220, 63, 46, 14);
		contentPanel.add(lblNewLabel_5);
		
		lblNewLabel_6 = new JLabel("%");
		lblNewLabel_6.setBounds(220, 99, 46, 14);
		contentPanel.add(lblNewLabel_6);
		
		lblNewLabel_7 = new JLabel("%");
		lblNewLabel_7.setBounds(220, 135, 46, 14);
		contentPanel.add(lblNewLabel_7);
		
		btnAceptar = new JButton("Aceptar");
		btnAceptar.addActionListener(this);
		btnAceptar.setBounds(335, 24, 89, 23);
		contentPanel.add(btnAceptar);
		
		btnCancelar = new JButton("Cancelar");
		btnCancelar.addActionListener(this);
		btnCancelar.setBounds(335, 59, 89, 23);
		contentPanel.add(btnCancelar);
	}
	public void actionPerformed(ActionEvent arg0) {
		if (arg0.getSource() == btnCancelar) {
			actionPerformedBtnCancelar(arg0);
		}
		if (arg0.getSource() == btnAceptar) {
			actionPerformedBtnAceptar(arg0);
		}
	}
	
	//En este metodo cambiamos los porcentajes
	protected void actionPerformedBtnAceptar(ActionEvent arg0) {
		//Obtenemos el texto de la caja de texto, lo convertimos a double, una vez un numero double lo dividimos entre 100 y lo almacenamos
		Tienda.porcentaje1=Double.parseDouble(txtPrimerPorcentaje.getText())/100;
		Tienda.porcentaje2=Double.parseDouble(txtSegundoDescuento.getText())/100;
		Tienda.porcentaje3=Double.parseDouble(txtTecerDescuento.getText())/100;
		Tienda.porcentaje4=Double.parseDouble(txtCuartoDescuento.getText())/100;
	}
	
	protected void actionPerformedBtnCancelar(ActionEvent arg0) {
		dispose();
	}
}
