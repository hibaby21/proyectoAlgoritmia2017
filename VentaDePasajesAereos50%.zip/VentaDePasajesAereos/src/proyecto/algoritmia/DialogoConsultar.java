package proyecto.algoritmia;

import java.awt.BorderLayout;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;


public class DialogoConsultar extends JDialog implements ActionListener, ItemListener {

	private final JPanel contentPanel = new JPanel();
    private JComboBox cboTipoDeBoleto;
	private JComboBox cboDestino;
	private JLabel lblClase;
	private JTextField txtPrecio;
	private JTextField txtCantMaletas;
	private JTextField txtCantPuntos;
	private JLabel lblNewLabel;
	private JLabel lblNewLabel_1;
	private JLabel lblNewLabel_2;	
	
	//Declaracion de variables
	int tipoDeBoleto, destino;
	private JButton btnCerrar;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			DialogoModificar dialog = new DialogoModificar();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public DialogoConsultar() {
		setTitle("Consultar");
		setBounds(100, 100, 511, 300);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		{
			JLabel lblDestino = new JLabel("Destino");
			lblDestino.setBounds(10, 22, 91, 14);
			contentPanel.add(lblDestino);
		}
		
		cboTipoDeBoleto = new JComboBox();
		cboTipoDeBoleto.setModel(new DefaultComboBoxModel(new String[] {"Economico", "Economico Premium", "Negocios", "Primera"}));
		cboTipoDeBoleto.setBounds(132, 53, 115, 20);
		cboTipoDeBoleto.addItemListener(this);
		contentPanel.add(cboTipoDeBoleto);
		
		cboDestino = new JComboBox();
		cboDestino.setModel(new DefaultComboBoxModel(new String[] {"Brazil", "Estados Unidos", "Mexico", "Puerto Rico", "Rusia"}));
		cboDestino.setBounds(132, 19, 115, 20);
		cboDestino.addItemListener(this);
		contentPanel.add(cboDestino);
		
		lblClase = new JLabel("Tipo de boleto");
		lblClase.setBounds(10, 56, 91, 14);
		contentPanel.add(lblClase);
		
		txtPrecio = new JTextField();
		txtPrecio.setEditable(false);
		txtPrecio.setBounds(132, 88, 115, 20);
		contentPanel.add(txtPrecio);
		txtPrecio.setColumns(10);
		txtPrecio.setText(String.valueOf(Tienda.preciosDeBoletosBr[0]));
		
		txtCantMaletas = new JTextField();
		txtCantMaletas.setEditable(false);
		txtCantMaletas.setBounds(132, 124, 115, 20);
		contentPanel.add(txtCantMaletas);
		txtCantMaletas.setColumns(10);
		txtCantMaletas.setText(String.valueOf(Tienda.cantidadDeMaletasBr[0]));
		
		txtCantPuntos = new JTextField();
		txtCantPuntos.setEditable(false);
		txtCantPuntos.setBounds(132, 157, 115, 20);
		contentPanel.add(txtCantPuntos);
		txtCantPuntos.setColumns(10);
		txtCantPuntos.setText(String.valueOf(Tienda.cantidadDePuntosBr[0]));
		
		lblNewLabel = new JLabel("Precio");
		lblNewLabel.setBounds(10, 91, 46, 14);
		contentPanel.add(lblNewLabel);
		
		lblNewLabel_1 = new JLabel("Cantidad de maletas");
		lblNewLabel_1.setBounds(10, 127, 124, 14);
		contentPanel.add(lblNewLabel_1);
		
		lblNewLabel_2 = new JLabel("Puntos Ganados");
		lblNewLabel_2.setBounds(10, 160, 91, 14);
		contentPanel.add(lblNewLabel_2);
		
		btnCerrar = new JButton("Cerrar");
		btnCerrar.addActionListener(this);
		btnCerrar.setBounds(396, 18, 89, 23);
		contentPanel.add(btnCerrar);
	}
	
		@Override
		public void itemStateChanged(ItemEvent e) {
			// TODO Auto-generated method stub
			if (e.getSource()==cboTipoDeBoleto) {
				tipoDeBoleto =  cboTipoDeBoleto.getSelectedIndex();
				destino = cboDestino.getSelectedIndex();
				mostrar();
			}
			
			if (e.getSource()==cboDestino) {
				tipoDeBoleto =  cboTipoDeBoleto.getSelectedIndex();
				destino = cboDestino.getSelectedIndex();
				mostrar();
			}
			
			
		}

		
		void mostrar(){
			if(destino==0){
				txtPrecio.setText(String.valueOf(Tienda.preciosDeBoletosBr[tipoDeBoleto]));
				txtCantMaletas.setText(String.valueOf(Tienda.cantidadDeMaletasBr[tipoDeBoleto]));
				txtCantPuntos.setText(String.valueOf(Tienda.cantidadDePuntosBr[tipoDeBoleto]));
			} else if(destino==1){
				txtPrecio.setText(String.valueOf(Tienda.preciosDeBoletosEUA[tipoDeBoleto]));
				txtCantMaletas.setText(String.valueOf(Tienda.cantidadDeMaletasEUA[tipoDeBoleto]));
				txtCantPuntos.setText(String.valueOf(Tienda.cantidadDePuntosEUA[tipoDeBoleto]));
			}else if(destino==2){
				txtPrecio.setText(String.valueOf(Tienda.preciosDeBoletosMx[tipoDeBoleto]));
				txtCantMaletas.setText(String.valueOf(Tienda.cantidadDeMaletasMx[tipoDeBoleto]));
				txtCantPuntos.setText(String.valueOf(Tienda.cantidadDePuntosMx[tipoDeBoleto]));
			} else if (destino==3) {
				txtPrecio.setText(String.valueOf(Tienda.preciosDeBoletosPr[tipoDeBoleto]));
				txtCantMaletas.setText(String.valueOf(Tienda.cantidadDeMaletasPr[tipoDeBoleto]));
				txtCantPuntos.setText(String.valueOf(Tienda.cantidadDePuntosPr[tipoDeBoleto]));
			} else{
				txtPrecio.setText(String.valueOf(Tienda.preciosDeBoletosRu[tipoDeBoleto]));
				txtCantMaletas.setText(String.valueOf(Tienda.cantidadDeMaletasRu[tipoDeBoleto]));
				txtCantPuntos.setText(String.valueOf(Tienda.cantidadDePuntosRu[tipoDeBoleto]));
			}
		}
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == btnCerrar) {
			actionPerformedBtnCerrar(e);
		}
	}
	protected void actionPerformedBtnCerrar(ActionEvent e) {
		dispose();
	}
}
